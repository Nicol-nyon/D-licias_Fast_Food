-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 06-10-2025 a las 22:58:36
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `brosteria`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `articulo`
--

CREATE TABLE `articulo` (
  `id_articulo` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `disponibilidad` tinyint(1) NOT NULL DEFAULT 1,
  `id_categoria` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `articulo`
--

INSERT INTO `articulo` (`id_articulo`, `nombre`, `precio`, `disponibilidad`, `id_categoria`) VALUES
(15, 'Porción de papa', 4.00, 1, 'ADI'),
(16, 'Porción de arroz', 4.00, 1, 'ADI'),
(17, 'Huevo', 1.00, 1, 'ADI'),
(18, 'Porción de Hot Dog', 1.50, 1, 'ADI'),
(19, 'Chorizo', 1.50, 1, 'ADI'),
(20, 'Café', 2.00, 1, 'BEB'),
(21, 'Infusión', 1.50, 1, 'BEB'),
(22, 'Coca cola - Personal', 3.00, 1, 'BEB'),
(23, 'Inka cola - Personal', 3.00, 1, 'BEB'),
(24, 'Pepsi - Personal', 2.00, 1, 'BEB'),
(25, 'Gordita (625 Lt)', 4.00, 1, 'BEB'),
(26, 'Inka cola (1 Lt)', 6.00, 1, 'BEB'),
(27, 'Coca cola (1 Lt)', 6.00, 1, 'BEB'),
(28, 'Inka cola (2 Lt)', 10.00, 1, 'BEB'),
(29, 'Coca cola (2 Lt)', 10.00, 1, 'BEB'),
(30, 'Agua mineral', 2.00, 1, 'BEB'),
(31, 'Alita', 9.00, 1, 'BRO'),
(32, 'Encuentro', 12.00, 1, 'BRO'),
(33, 'Pecho', 13.00, 1, 'BRO'),
(34, 'Pierna', 10.00, 1, 'BRO'),
(35, 'Clásica', 6.00, 1, 'HAM'),
(36, 'Clásica carne casera', 8.00, 1, 'HAM'),
(37, 'Royal', 8.00, 1, 'HAM'),
(38, 'Royal carne casera', 10.00, 1, 'HAM'),
(39, 'Mosther', 13.00, 1, 'HAM'),
(40, 'Salchipapa', 6.00, 1, 'HAM'),
(41, 'Caldo solo', 10.00, 1, 'CAL'),
(42, 'Caldo con presa', 12.00, 1, 'CAL');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria_articulo`
--

CREATE TABLE `categoria_articulo` (
  `id_categoria` varchar(5) NOT NULL,
  `nombre_categoria` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `categoria_articulo`
--

INSERT INTO `categoria_articulo` (`id_categoria`, `nombre_categoria`) VALUES
('ADI', 'Adicionales'),
('BEB', 'Bebidas'),
('BRO', 'Broaster'),
('CAL', 'Caldo'),
('HAM', 'Hamburguesas');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comprobante_pago`
--

CREATE TABLE `comprobante_pago` (
  `id_comprobante` int(11) NOT NULL,
  `id_orden` int(11) NOT NULL,
  `id_empleado` varchar(5) NOT NULL,
  `fecha_emision` datetime NOT NULL,
  `tipo_comprobante` enum('boleta','factura') NOT NULL,
  `nombre_cliente` text DEFAULT NULL,
  `tipo_documento` enum('DNI','RUC','CE','PAST') DEFAULT NULL,
  `numero_documento` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `comprobante_pago`
--

INSERT INTO `comprobante_pago` (`id_comprobante`, `id_orden`, `id_empleado`, `fecha_emision`, `tipo_comprobante`, `nombre_cliente`, `tipo_documento`, `numero_documento`) VALUES
(80, 11, 'E0002', '2025-07-07 08:41:10', 'boleta', NULL, NULL, NULL),
(81, 12, 'E0002', '2025-07-07 08:41:10', 'boleta', NULL, NULL, NULL),
(82, 13, 'E0002', '2025-07-07 08:41:10', 'factura', 'Cliente 3', 'RUC', '20123456789'),
(83, 14, 'E0002', '2025-07-07 08:41:10', 'boleta', NULL, NULL, NULL),
(84, 15, 'E0002', '2025-07-07 08:41:10', 'boleta', NULL, NULL, NULL),
(85, 16, 'E0002', '2025-07-07 08:41:10', 'boleta', NULL, NULL, NULL),
(86, 17, 'E0002', '2025-07-07 08:41:10', 'factura', 'Cliente 7', 'RUC', '20123456780'),
(87, 18, 'E0002', '2025-07-07 08:41:10', 'boleta', NULL, NULL, NULL),
(88, 19, 'E0002', '2025-07-07 08:41:10', 'boleta', NULL, NULL, NULL),
(89, 20, 'E0002', '2025-07-07 08:41:10', 'boleta', NULL, NULL, NULL),
(90, 21, 'E0002', '2025-07-07 08:41:10', 'boleta', NULL, NULL, NULL),
(91, 22, 'E0002', '2025-07-07 08:41:10', 'boleta', NULL, NULL, NULL),
(92, 23, 'E0002', '2025-07-07 08:41:10', 'boleta', NULL, NULL, NULL),
(93, 24, 'E0002', '2025-07-07 08:41:10', 'factura', 'Cliente 14', 'RUC', '20123456781'),
(94, 25, 'E0002', '2025-07-07 08:41:10', 'boleta', NULL, NULL, NULL),
(95, 26, 'E0002', '2025-07-07 08:41:10', 'boleta', NULL, NULL, NULL),
(96, 27, 'E0002', '2025-07-07 08:41:10', 'boleta', NULL, NULL, NULL),
(97, 28, 'E0002', '2025-07-07 08:41:10', 'boleta', NULL, NULL, NULL),
(98, 29, 'E0002', '2025-07-07 08:41:10', 'boleta', NULL, NULL, NULL),
(99, 30, 'E0002', '2025-07-07 08:41:10', 'boleta', NULL, NULL, NULL),
(100, 11, 'E0002', '2025-07-07 08:41:19', 'boleta', NULL, NULL, NULL),
(101, 12, 'E0002', '2025-07-07 08:41:19', 'boleta', NULL, NULL, NULL),
(102, 13, 'E0002', '2025-07-07 08:41:19', 'factura', 'Cliente 3', 'RUC', '20123456789'),
(103, 14, 'E0002', '2025-07-07 08:41:19', 'boleta', NULL, NULL, NULL),
(104, 15, 'E0002', '2025-07-07 08:41:19', 'boleta', NULL, NULL, NULL),
(105, 16, 'E0002', '2025-07-07 08:41:19', 'boleta', NULL, NULL, NULL),
(106, 17, 'E0002', '2025-07-07 08:41:19', 'factura', 'Cliente 7', 'RUC', '20123456780'),
(107, 18, 'E0002', '2025-07-07 08:41:19', 'boleta', NULL, NULL, NULL),
(108, 19, 'E0002', '2025-07-07 08:41:19', 'boleta', NULL, NULL, NULL),
(109, 20, 'E0002', '2025-07-07 08:41:19', 'boleta', NULL, NULL, NULL),
(110, 21, 'E0002', '2025-07-07 08:41:19', 'boleta', NULL, NULL, NULL),
(111, 22, 'E0002', '2025-07-07 08:41:19', 'boleta', NULL, NULL, NULL),
(112, 23, 'E0002', '2025-07-07 08:41:19', 'boleta', NULL, NULL, NULL),
(113, 24, 'E0002', '2025-07-07 08:41:19', 'factura', 'Cliente 14', 'RUC', '20123456781'),
(114, 25, 'E0002', '2025-07-07 08:41:19', 'boleta', NULL, NULL, NULL),
(115, 26, 'E0002', '2025-07-07 08:41:19', 'boleta', NULL, NULL, NULL),
(116, 27, 'E0002', '2025-07-07 08:41:19', 'boleta', NULL, NULL, NULL),
(117, 28, 'E0002', '2025-07-07 08:41:19', 'boleta', NULL, NULL, NULL),
(118, 29, 'E0002', '2025-07-07 08:41:19', 'boleta', NULL, NULL, NULL),
(119, 30, 'E0002', '2025-07-07 08:41:19', 'boleta', NULL, NULL, NULL),
(120, 52, 'A0001', '2025-09-17 15:45:44', 'factura', 'EJEMPLO', 'RUC', '00000000'),
(121, 53, 'A0001', '2025-09-24 02:58:23', 'boleta', 'Consumidor Final', NULL, NULL),
(122, 52, 'A0001', '2025-09-24 03:11:31', '', 'Consumidor Final', NULL, NULL),
(123, 52, 'A0001', '2025-09-24 03:26:38', 'factura', 'Nombre de cliente (obligatorio)', 'RUC', '1234567891'),
(124, 52, 'A0001', '2025-09-24 03:30:30', 'factura', 'Nombre de cliente (obligatorio)', 'RUC', '1234567891'),
(125, 54, 'A0001', '2025-09-30 03:20:37', 'boleta', 'Consumidor Final', NULL, NULL),
(126, 53, 'A0001', '2025-09-30 03:42:04', 'boleta', 'Consumidor Final', NULL, NULL),
(127, 57, 'A0001', '2025-09-30 03:43:01', 'boleta', 'Consumidor Final', NULL, NULL),
(128, 57, 'A0001', '2025-09-30 03:45:19', 'boleta', 'Consumidor Final', NULL, NULL),
(129, 57, 'A0001', '2025-09-30 03:45:22', 'boleta', 'Consumidor Final', NULL, NULL),
(130, 57, 'A0001', '2025-09-30 03:45:33', 'boleta', 'Consumidor Final', NULL, NULL),
(131, 57, 'A0001', '2025-09-30 03:48:15', 'boleta', 'Consumidor Final', NULL, NULL),
(132, 57, 'A0001', '2025-09-30 03:50:13', 'boleta', 'Consumidor Final', NULL, NULL),
(133, 57, 'A0001', '2025-09-30 03:50:58', 'boleta', 'Consumidor Final', NULL, NULL),
(134, 57, 'A0001', '2025-09-30 03:51:21', 'boleta', 'Consumidor Final', NULL, NULL),
(135, 57, 'A0001', '2025-09-30 03:52:37', 'boleta', 'Consumidor Final', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_comprobante`
--

CREATE TABLE `detalle_comprobante` (
  `id_detalle_comprobante` int(11) NOT NULL,
  `id_comprobante` int(11) NOT NULL,
  `id_metodo` varchar(6) NOT NULL,
  `descripcion` text NOT NULL,
  `monto` decimal(10,2) NOT NULL CHECK (`monto` >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `detalle_comprobante`
--

INSERT INTO `detalle_comprobante` (`id_detalle_comprobante`, `id_comprobante`, `id_metodo`, `descripcion`, `monto`) VALUES
(78, 80, 'EFE', 'Pago en efectivo', 23.00),
(79, 81, 'YAP', 'Pago por Yape', 13.00),
(80, 82, 'PLI', 'Pago por Plin', 13.00),
(81, 83, 'EFE', 'Pago en efectivo', 8.00),
(82, 84, 'YAP', 'Pago por Yape', 6.00),
(83, 85, 'PLI', 'Pago por Plin', 8.00),
(84, 86, 'EFE', 'Pago en efectivo', 10.00),
(85, 87, 'YAP', 'Pago por Yape', 6.00),
(86, 88, 'PLI', 'Pago por Plin', 18.00),
(87, 89, 'EFE', 'Pago en efectivo', 12.00),
(88, 90, 'YAP', 'Pago por Yape', 8.00),
(89, 91, 'EFE', 'Pago en efectivo', 3.50),
(90, 92, 'YAP', 'Pago por Yape', 2.00),
(91, 93, 'EFE', 'Pago en efectivo', 10.00),
(92, 94, 'PLI', 'Pago por Plin', 10.00),
(93, 95, 'EFE', 'Pago en efectivo', 1.50),
(94, 96, 'YAP', 'Pago por Yape', 4.00),
(95, 97, 'PLI', 'Pago por Plin', 6.00),
(96, 98, 'EFE', 'Pago en efectivo', 3.00),
(97, 99, 'YAP', 'Pago por Yape', 10.00),
(98, 80, 'EFE', 'Pago en efectivo', 23.00),
(99, 81, 'YAP', 'Pago por Yape', 13.00),
(100, 82, 'PLI', 'Pago por Plin', 13.00),
(101, 83, 'EFE', 'Pago en efectivo', 8.00),
(102, 84, 'YAP', 'Pago por Yape', 6.00),
(103, 85, 'PLI', 'Pago por Plin', 8.00),
(104, 86, 'EFE', 'Pago en efectivo', 10.00),
(105, 87, 'YAP', 'Pago por Yape', 6.00),
(106, 88, 'PLI', 'Pago por Plin', 18.00),
(107, 89, 'EFE', 'Pago en efectivo', 12.00),
(108, 90, 'YAP', 'Pago por Yape', 8.00),
(109, 91, 'EFE', 'Pago en efectivo', 3.50),
(110, 92, 'YAP', 'Pago por Yape', 2.00),
(111, 93, 'EFE', 'Pago en efectivo', 10.00),
(112, 94, 'PLI', 'Pago por Plin', 10.00),
(113, 95, 'EFE', 'Pago en efectivo', 1.50),
(114, 96, 'YAP', 'Pago por Yape', 4.00),
(115, 97, 'PLI', 'Pago por Plin', 6.00),
(116, 98, 'EFE', 'Pago en efectivo', 3.00),
(117, 99, 'YAP', 'Pago por Yape', 10.00),
(118, 120, 'EFE', 'Pago total', 24.00),
(119, 121, 'PLI', 'Pago total', 2.00),
(120, 122, 'PLI', 'Pago total', 24.00),
(121, 123, 'PLI', 'Pago total', 24.00),
(122, 124, 'EFE', 'Pago total', 24.00),
(123, 125, 'EFE', 'Pago total', 10.00),
(124, 126, 'EFE', 'Pago total', 2.00),
(125, 127, 'PLI', 'Pago total', 13.00),
(126, 128, 'EFE', 'Pago total', 13.00),
(127, 129, 'PLI', 'Pago total', 13.00),
(128, 130, 'EFE', 'Pago total', 13.00),
(129, 131, 'EFE', 'Pago total', 13.00),
(130, 132, 'EFE', 'Pago total', 13.00),
(131, 133, 'EFE', 'Pago total', 13.00),
(132, 134, 'EFE', 'Pago total', 13.00),
(133, 135, 'PLI', 'Pago total', 13.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_pedido`
--

CREATE TABLE `detalle_pedido` (
  `id_detalle` int(11) NOT NULL,
  `id_orden` int(11) DEFAULT NULL,
  `id_articulo` int(11) DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  `precio_unitario` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `detalle_pedido`
--

INSERT INTO `detalle_pedido` (`id_detalle`, `id_orden`, `id_articulo`, `cantidad`, `precio_unitario`) VALUES
(52, 11, 34, 2, 10.00),
(53, 11, 23, 1, 3.00),
(54, 12, 33, 1, 13.00),
(55, 13, 39, 1, 13.00),
(56, 14, 25, 2, 4.00),
(57, 15, 35, 1, 6.00),
(58, 16, 37, 1, 8.00),
(59, 17, 41, 1, 10.00),
(60, 18, 40, 1, 6.00),
(61, 19, 31, 2, 9.00),
(62, 20, 32, 1, 12.00),
(63, 21, 36, 1, 8.00),
(64, 22, 30, 1, 2.00),
(65, 22, 18, 1, 1.50),
(66, 23, 17, 2, 1.00),
(67, 24, 29, 1, 10.00),
(68, 25, 28, 1, 10.00),
(69, 26, 21, 1, 1.50),
(70, 27, 20, 2, 2.00),
(71, 28, 26, 1, 6.00),
(72, 29, 19, 2, 1.50),
(73, 30, 38, 1, 10.00),
(74, 11, 34, 2, 10.00),
(75, 11, 23, 1, 3.00),
(76, 12, 33, 1, 13.00),
(77, 13, 39, 1, 13.00),
(78, 14, 25, 2, 4.00),
(79, 15, 35, 1, 6.00),
(80, 16, 37, 1, 8.00),
(81, 17, 41, 1, 10.00),
(82, 18, 40, 1, 6.00),
(83, 19, 31, 2, 9.00),
(84, 20, 32, 1, 12.00),
(85, 21, 36, 1, 8.00),
(86, 22, 30, 1, 2.00),
(87, 22, 18, 1, 1.50),
(88, 23, 17, 2, 1.00),
(89, 24, 29, 1, 10.00),
(90, 25, 28, 1, 10.00),
(91, 26, 21, 1, 1.50),
(92, 27, 20, 2, 2.00),
(93, 28, 26, 1, 6.00),
(94, 29, 19, 2, 1.50),
(95, 30, 38, 1, 10.00),
(96, 51, 15, 11, 4.00),
(97, 52, 15, 1, 4.00),
(98, 52, 41, 1, 10.00),
(99, 52, 38, 1, 10.00),
(100, 53, 24, 1, 2.00),
(101, 54, 41, 1, 10.00),
(102, 55, 24, 1, 2.00),
(103, 56, 15, 1, 4.00),
(104, 57, 39, 1, 13.00),
(105, 58, 33, 1, 13.00),
(106, 59, 33, 1, 13.00),
(107, 60, 33, 1, 13.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleado`
--

CREATE TABLE `empleado` (
  `id_empleado` varchar(5) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) DEFAULT NULL,
  `password` varchar(12) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `status` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `cargo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `empleado`
--

INSERT INTO `empleado` (`id_empleado`, `nombre`, `apellido`, `password`, `status`, `cargo`) VALUES
('A0001', 'Administrador', 'Administrador', '1234', 'Online', 'admin'),
('E0001', 'Chef', 'Chef', '1234', 'Offline', 'Chef'),
('E0002', 'Mesero', 'Mesero', '1234', 'Offline', 'Mesero'),
('E0003', 'Edu', 'Rios', '1234', 'Offline', 'Chef'),
('E0004', 'Niicol', 'Paz', '1234', 'Offline', 'mesero');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `metodo_pago`
--

CREATE TABLE `metodo_pago` (
  `id_metodo` varchar(6) NOT NULL,
  `descripcion` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `metodo_pago`
--

INSERT INTO `metodo_pago` (`id_metodo`, `descripcion`) VALUES
('EFE', 'Efectivo'),
('PLI', 'Plin'),
('YAP', 'Yape');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `orden_pedido`
--

CREATE TABLE `orden_pedido` (
  `id_orden` int(11) NOT NULL,
  `fecha` datetime DEFAULT NULL,
  `specification` text DEFAULT NULL,
  `estado` varchar(30) DEFAULT NULL,
  `Tipo` text NOT NULL,
  `id_empleado` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `orden_pedido`
--

INSERT INTO `orden_pedido` (`id_orden`, `fecha`, `specification`, `estado`, `Tipo`, `id_empleado`) VALUES
(11, '2025-07-07 08:41:10', 'Sin cebolla', 'entregado', 'Local', 'E0002'),
(12, '2025-07-07 08:41:10', 'Extra picante', 'Entregado', 'Delivery', 'E0002'),
(13, '2025-07-07 08:41:10', 'Con huevo', 'Entregado', 'Local', 'E0002'),
(14, '2025-07-07 08:41:10', 'Sin sal', 'Entregado', 'Local', 'E0002'),
(15, '2025-07-07 08:41:10', '', 'Entregado', 'Delivery', 'E0002'),
(16, '2025-07-07 08:41:10', '', 'Entregado', 'Local', 'E0002'),
(17, '2025-07-07 08:41:10', 'Sin cebolla', 'Entregado', 'Local', 'E0002'),
(18, '2025-07-07 08:41:10', '', 'Entregado', 'Delivery', 'E0002'),
(19, '2025-07-07 08:41:10', 'Extra sal', 'Entregado', 'Local', 'E0002'),
(20, '2025-07-07 08:41:10', 'Sin mayonesa', 'Entregado', 'Local', 'E0002'),
(21, '2025-07-07 08:41:10', '', 'Entregado', 'Delivery', 'E0002'),
(22, '2025-07-07 08:41:10', 'Sin picante', 'Entregado', 'Local', 'E0002'),
(23, '2025-07-07 08:41:10', '', 'Entregado', 'Local', 'E0002'),
(24, '2025-07-07 08:41:10', 'Sin ají', 'Entregado', 'Local', 'E0002'),
(25, '2025-07-07 08:41:10', '', 'Entregado', 'Local', 'E0002'),
(26, '2025-07-07 08:41:10', 'Con doble carne', 'Entregado', 'Delivery', 'E0002'),
(27, '2025-07-07 08:41:10', '', 'Entregado', 'Local', 'E0002'),
(28, '2025-07-07 08:41:10', '', 'Entregado', 'Local', 'E0002'),
(29, '2025-07-07 08:41:10', '', 'Entregado', 'Delivery', 'E0002'),
(30, '2025-07-07 08:41:10', '', 'Entregado', 'Local', 'E0002'),
(31, '2025-07-07 08:41:19', 'Sin cebolla', 'Entregado', 'Local', 'E0002'),
(32, '2025-07-07 08:41:19', 'Extra picante', 'Entregado', 'Delivery', 'E0002'),
(33, '2025-07-07 08:41:19', 'Con huevo', 'Entregado', 'Local', 'E0002'),
(34, '2025-07-07 08:41:19', 'Sin sal', 'Entregado', 'Local', 'E0002'),
(35, '2025-07-07 08:41:19', '', 'Entregado', 'Delivery', 'E0002'),
(36, '2025-07-07 08:41:19', '', 'Entregado', 'Local', 'E0002'),
(37, '2025-07-07 08:41:19', 'Sin cebolla', 'Entregado', 'Local', 'E0002'),
(38, '2025-07-07 08:41:19', '', 'Entregado', 'Delivery', 'E0002'),
(39, '2025-07-07 08:41:19', 'Extra sal', 'Entregado', 'Local', 'E0002'),
(40, '2025-07-07 08:41:19', 'Sin mayonesa', 'Entregado', 'Local', 'E0002'),
(41, '2025-07-07 08:41:19', '', 'Entregado', 'Delivery', 'E0002'),
(42, '2025-07-07 08:41:19', 'Sin picante', 'Entregado', 'Local', 'E0002'),
(43, '2025-07-07 08:41:19', '', 'Entregado', 'Local', 'E0002'),
(44, '2025-07-07 08:41:19', 'Sin ají', 'Entregado', 'Local', 'E0002'),
(45, '2025-07-07 08:41:19', '', 'Entregado', 'Local', 'E0002'),
(46, '2025-07-07 08:41:19', 'Con doble carne', 'Entregado', 'Delivery', 'E0002'),
(47, '2025-07-07 08:41:19', '', 'Entregado', 'Local', 'E0002'),
(48, '2025-07-07 08:41:19', '', 'Entregado', 'Local', 'E0002'),
(49, '2025-07-07 08:41:19', '', 'Entregado', 'Delivery', 'E0002'),
(50, '2025-07-07 08:41:19', '', 'Entregado', 'Local', 'E0002'),
(51, '2025-09-12 00:00:00', 'ADFASDDAD', 'entregado', 'Local', 'E0002'),
(52, '2025-09-17 00:00:00', '', 'entregado', 'Local', 'E0002'),
(53, '2025-09-17 00:00:00', '', 'entregado', 'Hibrida', 'E0002'),
(54, '2025-09-19 00:00:00', '', 'entregado', 'Local', 'E0002'),
(55, '2025-09-19 00:00:00', '', 'entregado', 'Hibrida', 'E0002'),
(56, '2025-09-24 02:51:57', '', 'entregado', 'Local', 'E0002'),
(57, '2025-09-24 02:52:02', '', 'entregado', 'Llevar', 'E0002'),
(58, '2025-09-24 02:52:10', '', 'entregado', 'Hibrida', 'E0002'),
(59, '2025-09-24 04:01:57', '', 'entregado', 'Local', 'E0002'),
(60, '2025-09-30 03:10:10', '', 'entregado', 'Local', 'E0002');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `articulo`
--
ALTER TABLE `articulo`
  ADD PRIMARY KEY (`id_articulo`),
  ADD KEY `id_categoria` (`id_categoria`);

--
-- Indices de la tabla `categoria_articulo`
--
ALTER TABLE `categoria_articulo`
  ADD PRIMARY KEY (`id_categoria`);

--
-- Indices de la tabla `comprobante_pago`
--
ALTER TABLE `comprobante_pago`
  ADD PRIMARY KEY (`id_comprobante`),
  ADD KEY `id_orden` (`id_orden`),
  ADD KEY `id_empleado` (`id_empleado`);

--
-- Indices de la tabla `detalle_comprobante`
--
ALTER TABLE `detalle_comprobante`
  ADD PRIMARY KEY (`id_detalle_comprobante`),
  ADD KEY `id_comprobante` (`id_comprobante`),
  ADD KEY `id_metodo` (`id_metodo`);

--
-- Indices de la tabla `detalle_pedido`
--
ALTER TABLE `detalle_pedido`
  ADD PRIMARY KEY (`id_detalle`),
  ADD KEY `id_orden` (`id_orden`),
  ADD KEY `id_articulo` (`id_articulo`);

--
-- Indices de la tabla `empleado`
--
ALTER TABLE `empleado`
  ADD PRIMARY KEY (`id_empleado`);

--
-- Indices de la tabla `metodo_pago`
--
ALTER TABLE `metodo_pago`
  ADD PRIMARY KEY (`id_metodo`);

--
-- Indices de la tabla `orden_pedido`
--
ALTER TABLE `orden_pedido`
  ADD PRIMARY KEY (`id_orden`),
  ADD KEY `id_empleado` (`id_empleado`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `articulo`
--
ALTER TABLE `articulo`
  MODIFY `id_articulo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT de la tabla `comprobante_pago`
--
ALTER TABLE `comprobante_pago`
  MODIFY `id_comprobante` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=136;

--
-- AUTO_INCREMENT de la tabla `detalle_comprobante`
--
ALTER TABLE `detalle_comprobante`
  MODIFY `id_detalle_comprobante` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=134;

--
-- AUTO_INCREMENT de la tabla `detalle_pedido`
--
ALTER TABLE `detalle_pedido`
  MODIFY `id_detalle` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=108;

--
-- AUTO_INCREMENT de la tabla `orden_pedido`
--
ALTER TABLE `orden_pedido`
  MODIFY `id_orden` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `articulo`
--
ALTER TABLE `articulo`
  ADD CONSTRAINT `articulo_ibfk_1` FOREIGN KEY (`id_categoria`) REFERENCES `categoria_articulo` (`id_categoria`);

--
-- Filtros para la tabla `comprobante_pago`
--
ALTER TABLE `comprobante_pago`
  ADD CONSTRAINT `comprobante_pago_ibfk_1` FOREIGN KEY (`id_orden`) REFERENCES `orden_pedido` (`id_orden`),
  ADD CONSTRAINT `comprobante_pago_ibfk_2` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id_empleado`);

--
-- Filtros para la tabla `detalle_comprobante`
--
ALTER TABLE `detalle_comprobante`
  ADD CONSTRAINT `detalle_comprobante_ibfk_1` FOREIGN KEY (`id_comprobante`) REFERENCES `comprobante_pago` (`id_comprobante`),
  ADD CONSTRAINT `detalle_comprobante_ibfk_2` FOREIGN KEY (`id_metodo`) REFERENCES `metodo_pago` (`id_metodo`);

--
-- Filtros para la tabla `detalle_pedido`
--
ALTER TABLE `detalle_pedido`
  ADD CONSTRAINT `detalle_pedido_ibfk_1` FOREIGN KEY (`id_orden`) REFERENCES `orden_pedido` (`id_orden`),
  ADD CONSTRAINT `detalle_pedido_ibfk_2` FOREIGN KEY (`id_articulo`) REFERENCES `articulo` (`id_articulo`);

--
-- Filtros para la tabla `orden_pedido`
--
ALTER TABLE `orden_pedido`
  ADD CONSTRAINT `orden_pedido_ibfk_1` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id_empleado`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
