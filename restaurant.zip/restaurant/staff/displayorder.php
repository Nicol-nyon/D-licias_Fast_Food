<?php
	include("../functions.php");

	if((!isset($_SESSION['uid']) && !isset($_SESSION['username']) && isset($_SESSION['user_level'])) ) 
		header("Location: login.php");
	if($_SESSION['user_level'] != "staff")
		header("Location: login.php");
	if(empty($_GET['cmd'])) 
		die(); 

	// ==================== CURRENT ORDER ====================
	if ($_GET['cmd'] == 'currentorder') {
		$displayOrderQuery =  "
			SELECT o.id_orden, c.nombre_categoria, dp.id_articulo, a.nombre, dp.cantidad, o.estado
			FROM orden_pedido o
			LEFT JOIN detalle_pedido dp ON o.id_orden = dp.id_orden
			LEFT JOIN articulo a ON dp.id_articulo = a.id_articulo
			LEFT JOIN categoria_articulo c ON a.id_categoria = c.id_categoria
			WHERE o.estado IN ('Espera','Preparando','Listo')
		";
		if ($orderResult = $sqlconnection->query($displayOrderQuery)) {
			$currentspan = 0;
			if ($orderResult->num_rows == 0) {
				echo "<tr><td class='text-center' colspan='6'>No hay órdenes por ahora :)</td></tr>";
			} else {
				while($orderRow = $orderResult->fetch_array(MYSQLI_ASSOC)) {
					$rowspan = getCountID($orderRow["id_orden"], "id_orden", "detalle_pedido");
					if ($currentspan == 0)
						$currentspan = $rowspan;
					echo "<tr>";
					if ($currentspan == $rowspan) {
						echo "<td rowspan={$rowspan}># ".$orderRow['id_orden']."</td>";
					}
					echo "
						<td>".$orderRow['nombre_categoria']."</td>
						<td>".$orderRow['nombre']."</td>
						<td class='text-center'>".$orderRow['cantidad']."</td>
					";

					// badge: mostramos tal cual está en DB
					if ($currentspan == $rowspan) {
						$color = "badge badge-warning";
						// uso strtolower para decidir color también (por si viene con otra capitalización)
						switch (strtolower($orderRow['estado'])) {
							case 'espera':   $color = "badge badge-warning"; break;
							case 'preparando': $color = "badge badge-primary"; break;
							case 'listo':     $color = "badge badge-success"; break;
							default: $color = "badge badge-secondary"; break;
						}
						echo "<td class='text-center' rowspan={$rowspan}><span class='{$color}'>".$orderRow['estado']."</span></td>";
					}

					// BOTONES: normalizamos estado a minúsculas para las comparaciones
					if ($_SESSION['user_role'] != 'Mesero' && $currentspan == $rowspan) {
						$estado_norm = strtolower($orderRow['estado']);
						echo "<td class='text-center' rowspan={$rowspan}>";
						echo "<div class='d-flex justify-content-center flex-wrap'>";

						switch ($estado_norm) {
							case 'espera':
							case 'especia': // por si acaso hay errores tipográficos raros, pero prioridad 'espera'
								// mostrar Preparando + Listo + Cancelar
								echo "<button onclick='editStatus(this,".$orderRow['id_orden'].")' class='btn btn-outline-primary mx-2' value='preparando'>Preparando</button>";
								echo "<button onclick='editStatus(this,".$orderRow['id_orden'].")' class='btn btn-outline-success mx-2' value='listo'>Listo</button>";
								break;

							case 'preparando':
								// mostrar Listo + Cancelar
								echo "<button onclick='editStatus(this,".$orderRow['id_orden'].")' class='btn btn-outline-success mx-2' value='listo'>Listo</button>";
								break;

							case 'listo':
								// mostrar Limpiar + Cancelar
								echo "<button onclick='editStatus(this,".$orderRow['id_orden'].")' class='btn btn-outline-warning mx-2' value='finalizado'>Limpiar</button>";
								break;

							default:
								// estado desconocido: dejamos al menos Cancelar disponible
								break;
						}

						// Cancelar siempre aparece
						echo "<button onclick='editStatus(this,".$orderRow['id_orden'].")' class='btn btn-outline-danger mx-2' value='cancelado'>Cancelar</button>";

						echo "</div>";
						echo "</td>";
					}

					echo "</tr>";
					$currentspan--;
				}
			}
		}
	}

	// ==================== SEARCH ORDER ====================
	if ($_GET['cmd'] == 'searchOrder') {
		$orderId = $_GET['orderId'];
		$displayOrderQuery =  "
			SELECT o.id_orden, c.nombre_categoria, dp.id_articulo, a.nombre, dp.cantidad, o.estado
			FROM orden_pedido o
			LEFT JOIN detalle_pedido dp ON o.id_orden = dp.id_orden
			LEFT JOIN articulo a ON dp.id_articulo = a.id_articulo
			LEFT JOIN categoria_articulo c ON a.id_categoria = c.id_categoria
			WHERE o.id_orden = '$orderId' AND o.estado IN ('Espera','Preparando','Listo')
		";
		if ($orderResult = $sqlconnection->query($displayOrderQuery)) {
			$currentspan = 0;
			if ($orderResult->num_rows == 0) {
				echo "<tr><td class='text-center' colspan='6'>No se encontró la orden</td></tr>";
			} else {
				while($orderRow = $orderResult->fetch_array(MYSQLI_ASSOC)) {
					$rowspan = getCountID($orderRow["id_orden"], "id_orden", "detalle_pedido");
					if ($currentspan == 0)
						$currentspan = $rowspan;

					echo "<tr>";
					if ($currentspan == $rowspan) {
						echo "<td rowspan={$rowspan}># ".$orderRow['id_orden']."</td>";
					}
					echo "
						<td>".$orderRow['nombre_categoria']."</td>
						<td>".$orderRow['nombre']."</td>
						<td class='text-center'>".$orderRow['cantidad']."</td>
					";

					if ($currentspan == $rowspan) {
						$color = "badge badge-warning";
						switch (strtolower($orderRow['estado'])) {
							case 'espera':   $color = "badge badge-warning"; break;
							case 'preparando': $color = "badge badge-primary"; break;
							case 'listo':     $color = "badge badge-success"; break;
							default: $color = "badge badge-secondary"; break;
						}
						echo "<td class='text-center' rowspan={$rowspan}><span class='{$color}'>".$orderRow['estado']."</span></td>";
					}

					if ($_SESSION['user_role'] != 'Mesero' && $currentspan == $rowspan) {
						$estado_norm = strtolower($orderRow['estado']);
						echo "<td class='text-center' rowspan={$rowspan}>";
						echo "<div class='d-flex justify-content-center flex-wrap'>";

						switch ($estado_norm) {
							case 'espera':
								echo "<button onclick='editStatus(this,".$orderRow['id_orden'].")' class='btn btn-outline-primary mx-2' value='preparando'>Preparando</button>";
								echo "<button onclick='editStatus(this,".$orderRow['id_orden'].")' class='btn btn-outline-success mx-2' value='listo'>Listo</button>";
								break;
							case 'preparando':
								echo "<button onclick='editStatus(this,".$orderRow['id_orden'].")' class='btn btn-outline-success mx-2' value='listo'>Listo</button>";
								break;
							case 'listo':
								echo "<button onclick='editStatus(this,".$orderRow['id_orden'].")' class='btn btn-outline-warning mx-2' value='finalizado'>Limpiar</button>";
								break;
						}

						echo "<button onclick='editStatus(this,".$orderRow['id_orden'].")' class='btn btn-outline-danger mx-2' value='cancelado'>Cancelar</button>";

						echo "</div>";
						echo "</td>";
					}

					echo "</tr>";
					$currentspan--;
				}
			}
		}
	}

	// ==================== CURRENT READY ====================
	if ($_GET['cmd'] == 'currentready') {
		$latestReadyQuery = "SELECT id_orden FROM orden_pedido WHERE estado IN ('finalizado', 'Listo')";
		if ($result = $sqlconnection->query($latestReadyQuery)) {
			if ($result->num_rows == 0) {
				echo "<tr><td class='text-center'>Sin órdenes listas para servir.</td></tr>";
			}
			while($latestOrder = $result->fetch_array(MYSQLI_ASSOC)) {
				echo "<tr><td><i class='fas fa-bullhorn' style='color:green;'></i> <b>Orden #".$latestOrder['id_orden']."</b> lista para servir. 
				<a href='editstatus.php?id_orden=".$latestOrder['id_orden']."'><i class='fas fa-check float-right'></i></a></td></tr>";
			}
		}
	}

	// ==================== INVERTIR ORDER ====================
	if ($_GET['cmd'] == 'ivertirOrder') {
		$order = "ASC";
    	if (isset($_GET['order']) && ($_GET['order'] === "DESC" || $_GET['order'] === "ASC")) {
        	$order = $_GET['order'];
    	}
		$displayOrderQuery =  "
			SELECT o.id_orden, c.nombre_categoria, dp.id_articulo, a.nombre, dp.cantidad, o.estado
			FROM orden_pedido o
			LEFT JOIN detalle_pedido dp ON o.id_orden = dp.id_orden
			LEFT JOIN articulo a ON dp.id_articulo = a.id_articulo
			LEFT JOIN categoria_articulo c ON a.id_categoria = c.id_categoria
			WHERE o.estado IN ('Espera','Preparando','Listo')
			order BY o.id_orden $order
		";
		if ($orderResult = $sqlconnection->query($displayOrderQuery)) {
			$currentspan = 0;
			if ($orderResult->num_rows == 0) {
				echo "<tr><td class='text-center' colspan='6'>No hay órdenes por ahora :)</td></tr>";
			} else {
				while($orderRow = $orderResult->fetch_array(MYSQLI_ASSOC)) {
					$rowspan = getCountID($orderRow["id_orden"], "id_orden", "detalle_pedido");
					if ($currentspan == 0)
						$currentspan = $rowspan;

					echo "<tr>";
					if ($currentspan == $rowspan) {
						echo "<td rowspan={$rowspan}># ".$orderRow['id_orden']."</td>";
					}
					echo "
						<td>".$orderRow['nombre_categoria']."</td>
						<td>".$orderRow['nombre']."</td>
						<td class='text-center'>".$orderRow['cantidad']."</td>
					";
					if ($currentspan == $rowspan) {
						$color = "badge badge-warning";
						switch (strtolower($orderRow['estado'])) {
							case 'espera':   $color = "badge badge-warning"; break;
							case 'preparando': $color = "badge badge-primary"; break;
							case 'listo':     $color = "badge badge-success"; break;
							default: $color = "badge badge-secondary"; break;
						}
						echo "<td class='text-center' rowspan={$rowspan}><span class='{$color}'>".$orderRow['estado']."</span></td>";
					}
					if ($_SESSION['user_role'] != 'Mesero' && $currentspan == $rowspan) {
						$estado_norm = strtolower($orderRow['estado']);
						echo "<td class='text-center' rowspan={$rowspan}>";
						echo "<div class='d-flex justify-content-center flex-wrap'>";

						switch ($estado_norm) {
							case 'espera':
								echo "<button onclick='editStatus(this,".$orderRow['id_orden'].")' class='btn btn-outline-primary mx-2' value='preparando'>Preparando</button>";
								echo "<button onclick='editStatus(this,".$orderRow['id_orden'].")' class='btn btn-outline-success mx-2' value='listo'>Listo</button>";
								break;
							case 'preparando':
								echo "<button onclick='editStatus(this,".$orderRow['id_orden'].")' class='btn btn-outline-success mx-2' value='listo'>Listo</button>";
								break;
							case 'listo':
								echo "<button onclick='editStatus(this,".$orderRow['id_orden'].")' class='btn btn-outline-warning mx-2' value='finalizado'>Limpiar</button>";
								break;
						}

						echo "<button onclick='editStatus(this,".$orderRow['id_orden'].")' class='btn btn-outline-danger mx-2' value='cancelado'>Cancelar</button>";
						echo "</div></td>";
					}
					echo "</tr>";
					$currentspan--;
				}
			}
		}
	}
?>
