<?php 
include("../functions.php");
if (isset($_POST['username']) && isset($_POST['password'])) {
    $username = $sqlconnection->real_escape_string($_POST['username']);
    $passwordInput = $_POST['password'];
    $sql = "SELECT * FROM empleado WHERE nombre = '$username'";
    if ($result = $sqlconnection->query($sql)) {
        if ($row = $result->fetch_array(MYSQLI_ASSOC)) {
            $passwordHash = $row['password'];
            if ($passwordInput === $passwordHash || password_verify($passwordInput, $passwordHash)) {
                $_SESSION['uid'] = $row['id_empleado'];
                $_SESSION['username'] = $row['nombre'];
                $_SESSION['user_level'] = "staff";
                $_SESSION['user_role'] = $row['cargo']; 
                echo "correct";
                //Cambia el estado del empleado a "Online" al ser correcta la contraseña
                $uid = $_SESSION['uid'];
                $sqlconnection->query("UPDATE empleado SET status = 'Online' WHERE id_empleado = '$uid'");
            } else {
                echo "Contraseña incorrecta.";
            }
        } else {
            echo "Usuario no encontrado.";
        }
    } else {
        echo "Error en la consulta: " . $sqlconnection->error;
    }
} else {
    echo "Faltan datos del formulario.";
}
?>