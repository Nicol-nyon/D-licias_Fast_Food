<?php
  include("../functions.php");
  if((!isset($_SESSION['uid']) || !isset($_SESSION['username']) || !isset($_SESSION['user_level'])) || $_SESSION['user_level'] != "staff") {
    header("Location: login.php");
    exit();
  }
  if (isset($_POST['btnStatus']) && isset($_POST['staffid'])) {
    $btnStatus = $sqlconnection->real_escape_string($_POST['btnStatus']);
    $staffID = $sqlconnection->real_escape_string($_POST['staffid']);
    if ($btnStatus === "Online") {
      $status = "Free time";
    }elseif ($btnStatus === "Free time"){
      $status = "Online";
    } else {
      echo "Estado no reconocido.";
      exit();
    }
    $checkIDQuery = "SELECT id_empleado FROM empleado WHERE id_empleado = '{$staffID}' LIMIT 1";
    $result = $sqlconnection->query($checkIDQuery);
    if ($result && $result->num_rows > 0) {
      $updateQuery = "UPDATE empleado SET status = '{$status}' WHERE id_empleado = '{$staffID}'";
      if ($sqlconnection->query($updateQuery) === TRUE) {
        header("Location: index.php");
        exit();
      } else {
        echo "Error al actualizar estado: " . $sqlconnection->error;
      }
    } else {
      echo "Empleado con ID '{$staffID}' no encontrado.";
    }
  } else {
    echo "Datos incompletos.";
  }
?>