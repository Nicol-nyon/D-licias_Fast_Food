<?php
include("../functions.php");
if (session_status() === PHP_SESSION_NONE) session_start();
header('Content-Type: application/json; charset=utf-8');
if (!isset($_SESSION['uid']) || $_SESSION['user_role'] != "Chef") {
  http_response_code(403);
  echo json_encode(['status'=>'error','message'=>'No autorizado']);
  exit();
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  http_response_code(405);
  echo json_encode(['status'=>'error','message'=>'Método no permitido']);
  exit();
}
$id_articulo = isset($_POST['id_articulo']) ? intval($_POST['id_articulo']) : null;
$disponibilidad = isset($_POST['disponibilidad']) ? intval($_POST['disponibilidad']) : null;
if ($id_articulo === null || $disponibilidad === null) {
  http_response_code(400);
  echo json_encode(['status'=>'error','message'=>'Parámetros faltantes']);
  exit();
}
$nuevo = ($disponibilidad === 1) ? 0 : 1;
$stmt = $sqlconnection->prepare("UPDATE articulo SET disponibilidad = ? WHERE id_articulo = ?");
if (!$stmt) {
  error_log("prepare failed: " . $sqlconnection->error);
  http_response_code(500);
  echo json_encode(['status'=>'error','message'=>'Error interno (prepare)']);
  exit();
}
$stmt->bind_param('ii', $nuevo, $id_articulo);
if (!$stmt->execute()) {
  error_log("execute failed: " . $stmt->error);
  http_response_code(500);
  echo json_encode(['status'=>'error','message'=>'Error al actualizar']);
  $stmt->close();
  exit();
}
$stmt->close();
echo json_encode(['status'=>'ok','nuevo'=>$nuevo]);