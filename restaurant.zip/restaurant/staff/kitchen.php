<?php
  include("../functions.php");
  if((!isset($_SESSION['uid']) && !isset($_SESSION['username']) && isset($_SESSION['user_level'])) ) 
    header("Location: login.php");
  if($_SESSION['user_level'] != "staff")
    header("Location: login.php");
  if($_SESSION['user_role'] != "Chef") {
    echo ("<script>window.alert('Available for chef only!'); window.location.href='index.php';</script>");
    exit();
  }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Cocina - D'licias Fast Food Empleado</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <link href="css/sb-admin.css" rel="stylesheet">
  </head>
  <body id="page-top">
    <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
      <a class="navbar-brand mr-1" href="index.php">D'licias Fast Food</a>
      <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
        <i class="fas fa-bars"></i>
      </button>
      <ul class="navbar-nav ml-auto ml-md-0">
        <li class="nav-item dropdown no-arrow">
          <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-user-circle fa-fw"></i>
          </a>
        </li>
      </ul>
    </nav>
    <div id="wrapper">
      <ul class="sidebar navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="index.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Panel de Control</span>
          </a>
        </li>
        <?php
          if ($_SESSION['user_role'] == "Mesero") {
            echo '
            <li class="nav-item">
              <a class="nav-link" href="order.php">
                <i class="fas fa-fw fa-book"></i>
                <span>Orden</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="inventori.php">
                <i class="fas fa-fw fa-boxes"></i>
                <span>Inventario</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="ediorder.php">
                <i class="fas fa-edit"></i>
                <span>Busqueda y Edicion</span>
              </a>
            </li>
          ';
          }
          if ($_SESSION['user_role'] == "Chef") {
            echo '
            <li class="nav-item">
              <a class="nav-link" href="kitchen.php">
                <i class="fas fa-fw fa-utensils"></i>
                <span>Kitchen</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="chefmenu.php">
                <i class="fas fa-fw fa-concierge-bell"></i>
                <span>Disponibilidad de Articulos / Platillos</span></a>
            </li>
            ';
          }
        ?>
        <?php include("accesibilidad.php"); ?>
        <li class="nav-item">
          <a class="nav-link" href="#" data-toggle="modal" data-target="#logoutModal">
            <i class="fas fa-fw fa-power-off"></i>
            <span>Cerrar Sesión</span>
          </a>
        </li>
      </ul>
      <div id="content-wrapper">
        <div class="container-fluid">
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="index.php">Panel de Control</a>
            </li>
            <li class="breadcrumb-item active">Cocina</li>
          </ol>
          <h1>Administración de la Cocina</h1>
          <hr>
          <p>Visualizar las ordenes de pedido, buscar, limpiar pedidos ya despachados.</p>
          <div class="card mb-3">
            <div class="card-header" style="background-color:#8e5a21; color:ghostwhite;">
              <i class="fas fa-utensils"></i>
              Listado de Últimas Órdenes Recibidas</div>
              <div class="card-body">
                <div class="row mb-3">
                  <div class="col-md-6">		 
                    <input type="text" id="searchOrderId" class="form-control" placeholder="Buscar por ID de orden" style="background-image: url('sarten.gif'); background-position: right 5px center; background-repeat: no-repeat; background-size: 35px 35px; padding-right: 30px;">		       		         
                  </div>
                  <div class="col-md-6 d-flex align-items-center">
                    <button class="btn btn-primary mr-2" onclick="searchOrder()">Buscar</button>
                    <button id="clearButton" class="btn btn-secondary mr-2">Limpiar</button>
                    <button id="interOrder" class="btn btn-warning">Invertir Orden</button>
                  </div>
                </div>
                <table id="tblCurrentOrder" class="table table-bordered text-center" width="100%" cellspacing="0">
                  <thead>
                    <th class='text-center table-dark'># de Orden</th>
                    <th class='text-center table-dark'>Categoría</th>
                    <th class='text-center table-dark'>Nombre del Menú</th>
                    <th class='text-center table-dark'>Cantidad</th>
                    <th class='text-center table-dark'>Estado</th>
                    <th class='text-center table-dark'>Opciones</th>
                  </thead>
                  <tbody id="tblBodyCurrentOrder">
                  </tbody>
                </table>
              </div>
            </div>
        </div>
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Sistema 2025 | D'licias Fast Food</span>
            </div>
          </div>
        </footer>
      </div>
    </div>
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header" style="background-color:#feefc4; color:black;">
            <h5 class="modal-title" id="exampleModalLabel">¿Realmente desea cerrar la sesión?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Seleccione "Cerrar sesión" a continuación si está listo para finalizar su sesión actual.</div>
          <div class="modal-footer">
            <button class="btn btn-warning" type="button" data-dismiss="modal">Cancelar</button>
            <a class="btn btn-danger" href="logout.php">Cerrar Sesión</a>
          </div>
        </div>
      </div>
    </div>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/sb-admin.min.js"></script>
    <script src="js/kitchen.js"></script>
    <script type="text/javascript">
    let order = "ASC ";
    let autoRefresh = true;
    $(document).ready(function() {
        // Botón para invertir
        $("#interOrder").on("click", function() {
            order = (order === "ASC ") ? "DESC " : "ASC ";
            invertTable();
        });
        // Botón limpiar búsqueda
        $("#clearButton").on("click", function() {
            $("#searchOrderId").val('');
            autoRefresh = true;
            refreshTableOrder();
        });
        refreshTableOrder();
        // Actualización automática cada 3 segundos
        setInterval(function() { refreshTableOrder(); }, 3000);
    });
    // Función para actualizar tabla normalmente (currentorder)
    function refreshTableOrder() {
        if(autoRefresh) {
            $("#tblBodyCurrentOrder").load("displayorder.php?cmd=currentorder&order=" + order);
        }
    }
    // Función para invertir la tabla (ivertirOrder)
    function invertTable() {
        autoRefresh = false; // desactiva auto-refresh mientras invertimos
        $("#tblBodyCurrentOrder").load("displayorder.php?cmd=ivertirOrder&order=" + order);
    }
    // Función para buscar por ID (searchOrder)
    function searchOrder() {
        const orderId = $("#searchOrderId").val().trim();
        if(orderId !== "") {
            autoRefresh = false; // desactiva auto-refresh mientras buscamos
            $("#tblBodyCurrentOrder").load("displayorder.php?cmd=searchOrder&orderId=" + orderId);
        } else {
            autoRefresh = true;
            refreshTableOrder();
        }
    }
    // Función para editar el estado de una orden
    function editStatus(objBtn, orderID) {
        const status = objBtn.value;

        $.ajax({
            url: "editstatus.php",
            type: 'POST',
            data: {
                orderID: orderID,
                status: status
            },
            success: function(output) {
                // Después de actualizar estado, refrescar según el flujo actual
                if(!autoRefresh) {
                    // Si se está viendo invertido o buscando, recarga ese flujo
                    if($("#searchOrderId").val().trim() !== " ") {
                        searchOrder();
                    } else {
                        invertTable();
                    }
                } else {
                    refreshTableOrder();
                }
            }
        });
    }
</script>
  </body>
</html>