<?php
include("../functions.php");

if((!isset($_SESSION['uid']) && !isset($_SESSION['username']) && isset($_SESSION['user_level']))) 
  header("Location: login.php");
if($_SESSION['user_level'] != "staff")
  header("Location: login.php");
if($_SESSION['user_role'] != "Chef") {
  echo ("<script>window.alert('Disponible solo para Chefs'); window.location.href='index.php';</script>");
  exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Menú - D'licias Fast Food Empleado</title>
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="css/sb-admin.css" rel="stylesheet">
</head>

<body id="page-top">
  <!-- Navbar -->
  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
    <a class="navbar-brand mr-1" href="index.php">D'licias Fast Food</a>
    <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle">
      <i class="fas fa-bars"></i>
    </button>
    <ul class="navbar-nav ml-auto ml-md-0">
      <li class="nav-item dropdown no-arrow">
        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown">
          <i class="fas fa-user-circle fa-fw"></i>
        </a>
      </li>
    </ul>
  </nav>

  <div id="wrapper">
    <ul class="sidebar navbar-nav">
      <li class="nav-item"><a class="nav-link" href="index.php">
        <i class="fas fa-fw fa-tachometer-alt"></i><span> Panel de Control</span></a></li>
      <li class="nav-item"><a class="nav-link" href="kitchen.php">
        <i class="fas fa-fw fa-utensils"></i><span> Kitchen</span></a></li>
      <li class="nav-item active"><a class="nav-link" href="chefmenu.php">
        <i class="fas fa-fw fa-concierge-bell"></i><span> Disponibilidad de Artículos / Platillos</span></a></li>
      <?php include("accesibilidad.php"); ?>
      <li class="nav-item"><a class="nav-link" href="#" data-toggle="modal" data-target="#logoutModal">
        <i class="fas fa-fw fa-power-off"></i><span> Cerrar Sesión</span></a></li>
    </ul>
    <div id="content-wrapper">
      <div class="container-fluid">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Panel de Control</a></li>
          <li class="breadcrumb-item active">Disponibilidad</li>
        </ol>
        <h1>Disponibilidad de Artículos / Platillos</h1>
        <hr>
        <?php
          $catQuery = "SELECT id_categoria, nombre_categoria FROM categoria_articulo ORDER BY nombre_categoria ASC";
          $catResult = $sqlconnection->query($catQuery);
          if ($catResult && $catResult->num_rows > 0) {
            while ($cat = $catResult->fetch_assoc()) {
              $idCategoria = $cat['id_categoria'];
              $nombreCat = htmlspecialchars($cat['nombre_categoria']);
              echo "<div class='card mb-4 shadow-sm'>";
              echo "<div class='card-header bg-dark text-white'><i class='fas fa-list'></i> Categoría: <strong>$nombreCat</strong></div>";
              echo "<div class='card-body p-0'>";
              echo "<table class='table table-bordered text-center mb-0'>";
              echo "<thead class='thead-light'>
                      <tr>
                        <th>Artículo / Platillo</th>
                        <th>Estado</th>
                        <th>Acción</th>
                      </tr>
                    </thead><tbody>";
              $artQuery = "SELECT id_articulo, nombre, disponibilidad 
                           FROM articulo 
                           WHERE id_categoria = '$idCategoria'
                           ORDER BY nombre ASC";
              $artResult = $sqlconnection->query($artQuery);
              if ($artResult && $artResult->num_rows > 0) {
                while ($row = $artResult->fetch_assoc()) {
                  $id = (int)$row['id_articulo'];
                  $nombre = htmlspecialchars($row['nombre']);
                  $disp = (int)$row['disponibilidad'];
                  $badge = $disp === 1 
                      ? "<span class='badge badge-success'>Disponible</span>" 
                      : "<span class='badge badge-danger'>No Disponible</span>";
                  $btnText = $disp === 1 ? "No Disponible" : "Disponible";
                  $btnClass = $disp === 1 ? "btn-danger" : "btn-success";
                  echo "<tr>";
                  echo "<td>{$nombre}</td>";
                  echo "<td id='status-{$id}'>{$badge}</td>";
                  echo "<td><button class='btn {$btnClass} btn-sm toggle-btn' data-id='{$id}' data-disp='{$disp}'>".htmlspecialchars($btnText)."</button></td>";
                  echo "</tr>";
                }
              } else {
                echo "<tr><td colspan='3'>No hay artículos registrados en esta categoría.</td></tr>";
              }
              echo "</tbody></table></div></div>";
            }
          } else {
            echo "<div class='alert alert-warning'>No se encontraron categorías registradas.</div>";
          }
        ?>
      </div>
      <footer class="sticky-footer">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright © Sistema 2025 | D'licias Fast Food</span>
          </div>
        </div>
      </footer>
    </div>
  </div>
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header" style="background-color:#feefc4; color:black;">
          <h5 class="modal-title">¿Cerrar sesión?</h5>
          <button class="close" type="button" data-dismiss="modal"><span>×</span></button>
        </div>
        <div class="modal-body">Seleccione "Cerrar sesión" para finalizar su sesión actual.</div>
        <div class="modal-footer">
          <button class="btn btn-warning" type="button" data-dismiss="modal">Cancelar</button>
          <a class="btn btn-danger" href="logout.php">Cerrar Sesión</a>
        </div>
      </div>
    </div>
  </div>
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="js/sb-admin.min.js"></script>
  <script>
  $(document).on('click', '.toggle-btn', function() {
    var $btn = $(this);
    var id = parseInt($btn.data('id'), 10);
    var disp = parseInt($btn.data('disp'), 10);
    var originalText = $btn.text();
    $btn.prop('disabled', true).text('Guardando...');

    $.ajax({
      url: 'statuschefmenu.php',
      type: 'POST',
      dataType: 'json',
      data: { id_articulo: id, disponibilidad: disp },
      success: function(res) {
        if (res && res.status === 'ok') {
          var nuevo = parseInt(res.nuevo, 10);
          var $status = $('#status-' + id);
         if (nuevo === 1) { // Ahora está Disponible
            $status.html("<span class='badge badge-success'>Disponible</span>");
            $btn.text('No Disponible');
            // AÑADE ESTA LÍNEA
            $btn.removeClass('btn-success').addClass('btn-danger');
          } else { // Ahora No está Disponible
            $status.html("<span class='badge badge-danger'>No Disponible</span>");
            $btn.text('Disponible');
            // AÑADE ESTA LÍNEA
            $btn.removeClass('btn-danger').addClass('btn-success');
        }
          $btn.data('disp', nuevo);
        } else {
          alert('Error: ' + (res && res.message ? res.message : 'Respuesta inválida'));
        }
        $btn.prop('disabled', false);
      },
      error: function() {
        alert('Error de servidor. Intente nuevamente.');
        $btn.prop('disabled', false).text(originalText);
      }
    });
  });
  </script>
</body>
</html>