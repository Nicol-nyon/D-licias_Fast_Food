<?php
	include("../functions.php");
  if((!isset($_SESSION['uid']) && !isset($_SESSION['username']) && isset($_SESSION['user_level'])) ) 
    header("Location: login.php");
  if($_SESSION['user_level'] != "staff")
    header("Location: login.php");
  if($_SESSION['user_role'] != "Mesero"){
    echo ("<script>window.alert('Solo meseros disponibles!'); window.location.href='index.php';</script>");
    exit();
  }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Orden - D'licias Fast Food Empleado</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <link href="css/sb-admin.css" rel="stylesheet">
    <!-- SweetAlert2-->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  </head>
  <body id="page-top">
    <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
      <a class="navbar-brand mr-1" href="index.php">D'licias Fast Food</a>
      <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
        <i class="fas fa-bars"></i>
      </button>
    </nav>
    <div id="wrapper">
      <ul class="sidebar navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="index.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Panel de Control</span>
          </a>
        </li>
        <?php
          if ($_SESSION['user_role'] == "Mesero") {
            echo '
            <li class="nav-item">
              <a class="nav-link" href="order.php">
                <i class="fas fa-fw fa-book"></i>
                <span>Órden de Pedido</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="inventori.php">
                <i class="fas fa-fw fa-boxes"></i>
                <span>Inventario</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="ediorder.php">
                <i class="fas fa-edit"></i>
                <span>Busqueda y Edición</span>
              </a>
            </li>
          ';
          }
          if ($_SESSION['user_role'] == "Chef") {
            echo '
            <li class="nav-item">
              <a class="nav-link" href="kitchen.php">
                <i class="fas fa-fw fa-utensils"></i>
                <span>Kitchen</span></a>
            </li>
            ';
          }
        ?>
        <?php include("accesibilidad.php"); ?>
        <li class="nav-item">
          <a class="nav-link" href="#" data-toggle="modal" data-target="#logoutModal">
            <i class="fas fa-fw fa-power-off"></i>
            <span>Cerrar Sesión</span>
          </a>
        </li>
      </ul>
      <div id="content-wrapper">
        <div class="container-fluid">
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="index.php">Panel de Control</a>
            </li>
            <li class="breadcrumb-item active">Orden</li>
          </ol>
          <!-- Page Content -->
          <h1>Administración de Órdenes</h1>
          <hr>
          <p>Permite tomar pedidos, especificar detalles adicionales y seleccionar el tipo de orden de forma eficiente.</p>
          <div class="row">
            <div class="col-lg-6">
              <div class="card mb-3">
                <div class="card-header" style="background-color:#a1bcb9; color:black;">
                  <i class="fas fa-pen-square"></i>
                  Tomar Órdenes</div>
                <div class="card-body">
                  <table class="table table-bordered text-center" width="100%" cellspacing="0">
                  	<tr>
                  	<?php 
                      $menuQuery = "SELECT * FROM categoria_articulo";

                      if ($menuResult = $sqlconnection->query($menuQuery)) {
                        $counter = 0;
                        while($menuRow = $menuResult->fetch_array(MYSQLI_ASSOC)) { 
                          if ($counter >=3) {
                            echo "</tr>";
                            $counter = 0;
                          }
                          if($counter == 0) {
                            echo "<tr>";
                          } 
                          ?>
                          <td>
                            <button style="margin-bottom:4px;white-space: normal;" 
                                    class="btn btn-info" 
                                    onclick="displayItem('<?php echo $menuRow['id_categoria']?>')">
                              <?php echo $menuRow['nombre_categoria']?>
                            </button>
                          </td>
                          <?php
                          $counter++;
                        }
                      }
                      ?>
					          </tr>
                  </table>
                  <table id="tblItem" class="table table-bordered text-center" width="100%" cellspacing="0"></table>
                <div id="qtypanel" hidden="">
        					Cantidad:  <input id="qty" required="required" type="number" min="1" max="50" name="qty" value="1" />
        					<button class="btn btn-success" onclick = "insertItem()">Registrar</button>
        					<br><br>
				        </div>

                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="card mb-3">
                <div class="card-header" style="background-color:#a1bcb9; color:black;">
                  <i class="fas fa-receipt"></i>
                  Registro de órden(es)</div>
                <div class="card-body">
                    <form id="orderForm" action="insertorder.php" method="POST">
                      <table id="tblOrderList" class="table table-bordered text-center" width="100%" cellspacing="0">
                        <tr>
                          <th class='text-center table-dark'>Nombre</th>
                          <th class='text-center table-dark'>Precio</th>
                          <th class='text-center table-dark'>Cantidad</th>
                          <th class='text-center table-dark'>Total (PEN)</th>
                        </tr>
                      </table>
                      <div class="form-group">
                        <label for="specification">Especificación del pedido:</label>
                        <textarea class="form-control" name="specification" id="specification" rows="2" maxlength="255" placeholder="Ej: sin ensalada, sin mayonesa, etc."></textarea>
                      </div>
                      <div class="form-group">
                        <label for="tipo_pedido">Tipo de pedido:</label>
                        <select class="form-control" name="tipo_pedido" id="tipo_pedido" required>
                          <option value="" disabled selected>Seleccione una opción</option>
                          <option value="Local">Local</option>
                          <option value="Hibrida">Híbrida</option>
                          <option value="Llevar">Llevar</option>
                        </select>
                      </div>
                      <input class="btn btn-success" type="submit" id="btnSubmitOrder" name="sentorder" value="Enviar">
                    </form>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Sistema 2025 | D'licias Fast Food</span>
            </div>
          </div>
        </footer>
      </div>
    </div>
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>
    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header" style="background-color:#feefc4; color:black;">
            <h5 class="modal-title" id="exampleModalLabel">¿Realmente desea cerrar la sesión?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Seleccione "Cerrar sesión" si está listo para finalizar su sesión actual.</div>
          <div class="modal-footer">
            <button class="btn btn-warning" type="button" data-dismiss="modal">Cancelar</button>
            <a class="btn btn-danger" href="logout.php">Cerrar Sesión</a>
          </div>
        </div>
      </div>
    </div>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/sb-admin.min.js"></script>
    <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
	  <script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
	<script>
		var currentItemID = null;
		function displayItem (id) {
			$.ajax({
				url : "displayitem.php",
					type : 'POST',
					data : { btnMenuID : id },
					success : function(output) {
						$("#tblItem").html(output);
					}
				});
		}
		function insertItem () {
			var id = currentItemID;
			var quantity = $("#qty").val();
			$.ajax({
				url : "displayitem.php",
					type : 'POST',
					data : { 
						btnMenuItemID : id,
						qty : quantity 
					},
					success : function(output) {
						$("#tblOrderList").append(output);
						$("#qtypanel").prop('hidden',true);
					}
				});
			$("#qty").val(1);
		}
		function setQty (id) {
			currentItemID = id;
			$("#qtypanel").prop('hidden',false);
		}
		$(document).on('click','.deleteBtn', function(event){
		        event.preventDefault();
		        $(this).closest('tr').remove();
		        return false;
		    });
	</script>
  </body>
</html>
<script>
document.getElementById('orderForm').addEventListener('submit', function(event) { 
  const tipoPedido = document.getElementById('tipo_pedido').value; 
  const orderList = document.querySelectorAll('#tblOrderList tr').length; 
  const hasItems = orderList > 1; 
  if (!tipoPedido) { 
    event.preventDefault(); 
    Swal.fire({ 
      icon: 'warning', 
      title: 'Tipo de pedido requerido', 
      text: 'Por favor seleccione una opción: Local, Híbrida o Llevar.', 
      confirmButtonText: 'Entendido' 
    }); 
    return; 
  } 
  if (!hasItems) { 
    event.preventDefault(); 
    Swal.fire({ 
      icon: 'warning', 
      title: 'Pedido vacío', 
      text: 'Debe agregar al menos un producto antes de enviar el pedido.', 
      confirmButtonText: 'Entendido' 
    }); 
    return; 
    } 
}); 
</script>
<script>
  //actualiza el total cuando se cambia la cantidad
  $(document).on('input', '.qty-input', function () {
    const $row = $(this).closest('tr');
    const precio = parseFloat($(this).data('precio'));
    const cantidad = parseInt($(this).val());

    if (!isNaN(precio) && !isNaN(cantidad)) {
      const total = (precio * cantidad).toFixed(2);
      $row.find('.total').text(total);
    }
  });
</script>