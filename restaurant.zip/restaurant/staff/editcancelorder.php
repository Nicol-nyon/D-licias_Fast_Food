<?php 
include("../functions.php");
session_start();

// Validación de sesión
if ((!isset($_SESSION['uid']) && !isset($_SESSION['username']) && isset($_SESSION['user_level']))) 
    header("Location: login.php");
if ($_SESSION['user_level'] != "staff")
    header("Location: login.php");

// --- Acciones ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // --- Editar detalle ---
    if ($_POST['action'] == "editar") {
        $id_detalle = intval($_POST['id_detalle']);
        $nuevaCantidad = intval($_POST['nuevaCantidad']);
        $nuevoArticulo = intval($_POST['nuevoArticulo']);
        $nuevoPrecio = floatval($_POST['nuevoPrecio']);

        $sql = "UPDATE detalle_pedido 
                SET id_articulo = $nuevoArticulo, cantidad = $nuevaCantidad, precio_unitario = $nuevoPrecio 
                WHERE id_detalle = $id_detalle";

        if ($sqlconnection->query($sql)) {
            echo "OK";
        } else {
            http_response_code(500);
            echo "Error al actualizar detalle";
        }
    }

    // --- Cancelar un detalle específico ---
    elseif ($_POST['action'] == "cancelar") {
        $id_detalle = intval($_POST['id_detalle']);
        $getOrden = "SELECT id_orden FROM detalle_pedido WHERE id_detalle = $id_detalle";
        $res = $sqlconnection->query($getOrden);

        if ($res && $res->num_rows > 0) {
            $row = $res->fetch_assoc();
            $id_orden = $row['id_orden'];

            $deleteSQL = "DELETE FROM detalle_pedido WHERE id_detalle = $id_detalle";
            if ($sqlconnection->query($deleteSQL)) {

                // Si no quedan detalles, cambia estado de la orden
                $checkDetalles = "SELECT COUNT(*) as total FROM detalle_pedido WHERE id_orden = $id_orden";
                $resDetalles = $sqlconnection->query($checkDetalles);
                $rowDetalles = $resDetalles->fetch_assoc();

                if ($rowDetalles['total'] == 0) {
                    $updateOrden = "UPDATE orden_pedido SET estado = 'cancelado' WHERE id_orden = $id_orden";
                    $sqlconnection->query($updateOrden);
                }

                echo "OK";
            } else {
                http_response_code(500);
                echo "Error al cancelar el detalle";
            }
        } else {
            http_response_code(500);
            echo "No se encontró la orden asociada";
        }
    }

    // --- NUEVO: Eliminar toda la orden ---
    elseif ($_POST['action'] == "eliminar_orden") {
        $id_orden = intval($_POST['id_orden']);

        // Primero eliminamos los detalles de la orden
        $deleteDetalles = "DELETE FROM detalle_pedido WHERE id_orden = $id_orden";
        if (!$sqlconnection->query($deleteDetalles)) {
            http_response_code(500);
            echo "Error al eliminar los detalles del pedido";
            exit;
        }

        // Luego eliminamos la orden principal
        $deleteOrden = "DELETE FROM orden_pedido WHERE id_orden = $id_orden";
        if ($sqlconnection->query($deleteOrden)) {
            echo "Orden eliminada completamente";
        } else {
            http_response_code(500);
            echo "Error al eliminar la orden principal";
        }
    }

    exit;
}
?>
