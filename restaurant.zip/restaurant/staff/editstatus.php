<?php
	include("../functions.php");

	if((!isset($_SESSION['uid']) && !isset($_SESSION['username']) && isset($_SESSION['user_level']))) 
		header("Location: login.php");

	if($_SESSION['user_level'] != "staff")
		header("Location: login.php");

	if (isset($_POST['status']) && isset($_POST['orderID'])) {

		$estado = $sqlconnection->real_escape_string($_POST['status']);
		$id_orden = intval($_POST['orderID']);

		$estado = ucfirst(strtolower($estado));

		$query = "UPDATE orden_pedido SET estado = '{$estado}' WHERE id_orden = {$id_orden}";

		if ($sqlconnection->query($query) === TRUE) {
			echo "Estado actualizado a {$estado}.";
		} else {
			http_response_code(500);
			echo "Error: " . $sqlconnection->error;
		}
		exit;
	}

	if (isset($_GET['id_orden'])) {

		$id_orden = intval($_GET['id_orden']);
		$estado = "Entregado";

		$query = "UPDATE orden_pedido SET estado = '{$estado}' WHERE id_orden = {$id_orden}";

		if ($sqlconnection->query($query) === TRUE) {
			header("Location: index.php");
			exit;
		} else {
			echo "Error: " . $sqlconnection->error;
		}
	}
?>
