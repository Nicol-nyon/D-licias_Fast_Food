<?php
	include("../functions.php");
	if ((!isset($_SESSION['uid']) && !isset($_SESSION['username']) && isset($_SESSION['user_level']))) {
		header("Location: login.php");
	}
	if ($_SESSION['user_level'] != "staff") {
		header("Location: login.php");
	}
	if (isset($_POST['btnMenuID'])) {
		$menuID = $sqlconnection->real_escape_string($_POST['btnMenuID']);
		$menuItemQuery = "SELECT id_articulo, nombre FROM articulo WHERE id_categoria = '" . $menuID . "'";
		if ($menuItemResult = $sqlconnection->query($menuItemQuery)) {
			if ($menuItemResult->num_rows > 0) {
				$counter = 0;
				while ($menuItemRow = $menuItemResult->fetch_array(MYSQLI_ASSOC)) {
					if ($counter >= 3) {
						echo "</tr>";
						$counter = 0;
					}
					if ($counter == 0) {
						echo "<tr>";
					}
					echo "<td><button style='margin-bottom:4px;white-space: normal;' class='btn btn-warning' onclick = 'setQty(\"{$menuItemRow['id_articulo']}\")'>{$menuItemRow['nombre']}</button></td>";
					$counter++;
				}
			} else {
				echo "<tr><td>No hay artículos en esta categoría</td></tr>";
			}
		}
	}
	if (isset($_POST['btnMenuItemID']) && isset($_POST['qty'])) {
		$menuItemID = $sqlconnection->real_escape_string($_POST['btnMenuItemID']);
		$quantity = $sqlconnection->real_escape_string($_POST['qty']);
		$menuItemQuery = "SELECT mi.id_articulo, mi.nombre, mi.precio, mi.disponibilidad, m.nombre_categoria 
						FROM articulo mi 
						LEFT JOIN categoria_articulo m ON mi.id_categoria = m.id_categoria 
						WHERE mi.id_articulo = '" . $menuItemID . "'";
		if ($menuItemResult = $sqlconnection->query($menuItemQuery)) {
			if ($menuItemResult->num_rows > 0) {
				if ($menuItemRow = $menuItemResult->fetch_array(MYSQLI_ASSOC)) {
					if ($menuItemRow['disponibilidad'] != 1) {
						echo "<tr><td colspan='5' class='text-danger'>El producto '{$menuItemRow['nombre']}' no está disponible actualmente.</td></tr>";
						exit;
					}
					echo "
					<tr>
						<input type='hidden' name='itemID[]' value ='".$menuItemRow['id_articulo']."'/>
						<td>".$menuItemRow['nombre_categoria']." : ".$menuItemRow['nombre']."</td>
						<td class='precio'>".$menuItemRow['precio']."</td>
						<td> <input type='number' required='required' min='1' name='itemqty[]' class='form-control qty-input' value='".$quantity."' data-precio='".$menuItemRow['precio']."' /> </td>
						<td class='total'>" . number_format((float)$menuItemRow['precio'] * $quantity, 2, '.', '') . "</td>
						<td><button class='btn btn-danger deleteBtn' type='button' onclick='deleteRow()'><i class='fas fa-times'></i></button></td>
					</tr>
					";
				}
			} else {
				echo "<tr><td colspan='5' class='text-danger'>Producto no encontrado.</td></tr>";
			}
		} else {
			echo "<tr><td colspan='5' class='text-danger'>Error al buscar el producto: " . $sqlconnection->error . "</td></tr>";
		}
	}
?>
