<?php
  include("../functions.php");
  if((!isset($_SESSION['uid']) && !isset($_SESSION['username']) && isset($_SESSION['user_level'])) ) 
    header("Location: login.php");
  if($_SESSION['user_level'] != "staff")
    header("Location: login.php");
  if($_SESSION['user_role'] != "Mesero") {
    echo ("<script>window.alert('Available for chef only!'); window.location.href='index.php';</script>");
    exit();
  }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Busqueda y Edición - D'licias Fast Food Empleado</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <link href="css/sb-admin.css" rel="stylesheet">
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  </head>
  <body id="page-top">
    <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
      <a class="navbar-brand mr-1" href="index.php">D'licias Fast Food</a>
      <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
        <i class="fas fa-bars"></i>
      </button>
    </nav>
    <div id="wrapper">
      <ul class="sidebar navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="index.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Panel de Control</span>
          </a>
        </li>
        <?php
          if ($_SESSION['user_role'] == "Mesero") {
            echo '
            <li class="nav-item">
              <a class="nav-link" href="order.php">
                <i class="fas fa-fw fa-book"></i>
                <span>Órden de Pedido</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="inventori.php">
                <i class="fas fa-fw fa-boxes"></i>
                <span>Inventario</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="ediorder.php">
                <i class="fas fa-edit"></i>
                <span>Busqueda y Edición</span>
              </a>
            </li>
          ';
          }
          if ($_SESSION['user_role'] == "Chef") {
            echo '
            <li class="nav-item">
              <a class="nav-link" href="kitchen.php">
                <i class="fas fa-fw fa-utensils"></i>
                <span>Kitchen</span></a>
            </li>
            ';
          }
        ?>
        <?php include("accesibilidad.php"); ?>
        <li class="nav-item">
          <a class="nav-link" href="#" data-toggle="modal" data-target="#logoutModal">
            <i class="fas fa-fw fa-power-off"></i>
            <span>Cerrar Sesión</span>
          </a>
        </li>
      </ul>
      <div id="content-wrapper">
        <div class="container-fluid">
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="index.php">Panel de Control</a>
            </li>
            <li class="breadcrumb-item active">Busqueda y Edición</li>
          </ol>
          <h1>Órdenes pendientes</h1>
          <hr>
          <p>Muestra las órdenes en espera, permite buscarlas, ver sus detalles, editarlas o anularlas según sea necesario.</p>
          <form class="form-inline mb-3" method="GET" action="">
            <label class="mr-2" for="searchOrder">Buscar por ID de Orden:</label>
            <input type="number" class="form-control mr-2" name="searchOrder" min="1" id="searchOrder" placeholder="Ej: 101" style="background-image: url('sarten.gif'); background-position: right 2px center; background-repeat: no-repeat; background-size: 35px 35px; padding-right: 40px;">
            <button type="submit" class="btn btn-primary">Buscar</button>
          </form>
          <div class="card mb-3">
            <div class="card-header" style="background-color:#a1bcb9; color:ghostwhite;">
              <i class="fas fa-list-ol"></i>
              Listado de Últimas Órdenes Recibidas</div>
            <div class="card-body">
            	<table id="tblCurrentOrder" class="table table-bordered text-center" width="100%" cellspacing="0">
					<thead>
            <tr>
              <th class='text-center table-dark'>N° de Orden</th>
              <th class='text-center table-dark'>Categoría</th>
              <th class='text-center table-dark'>Nombre del Menú</th>
              <th class='text-center table-dark'>Cantidad</th>
              <th class='text-center table-dark'>Estado</th>
              <?php if (isset($_GET['searchOrder'])): ?>
                <th class='text-center table-dark'>Operaciones</th>
              <?php endif; ?>
            </tr>
          </thead>
					<tbody id="tblBodyCurrentOrder">
            <?php
              if (isset($_GET['searchOrder']) && is_numeric($_GET['searchOrder'])) {
                  $id = intval($_GET['searchOrder']);
                  $query = "SELECT o.id_orden, c.nombre_categoria, a.nombre, od.cantidad, o.estado 
                                    FROM detalle_pedido od
                                    JOIN orden_pedido o ON o.id_orden = od.id_orden
                                    JOIN articulo a ON a.id_articulo = od.id_articulo
                                    JOIN categoria_articulo c ON c.id_categoria = a.id_categoria
                                    WHERE o.id_orden = $id";

                  $result = $sqlconnection->query($query);
                  if ($result->num_rows > 0) {
                      while($row = $result->fetch_assoc()) {
                          $id_orden = $row['id_orden'];
                          $id_articulo = $row['nombre'];
                          $queryDetalle = "SELECT id_detalle, precio_unitario 
                                          FROM detalle_pedido 
                                          WHERE id_orden = $id_orden AND cantidad = {$row['cantidad']} LIMIT 1";
                          $detalle = $sqlconnection->query($queryDetalle)->fetch_assoc();

                          echo "<tr data-id_detalle='{$detalle['id_detalle']}'>";
                          echo "<td>".$row['id_orden']."</td>";
                          echo "<td>".$row['nombre_categoria']."</td>";
                          $articulos = $sqlconnection->query("SELECT id_articulo, nombre, precio FROM articulo");
                          $select = "<select class='form-control articulo'>";
                          while ($art = $articulos->fetch_assoc()) {
                              $selected = ($art['nombre'] === $row['nombre']) ? "selected" : "";
                              $select .= "<option value='{$art['id_articulo']}' data-precio='{$art['precio']}' $selected>{$art['nombre']}</option>";
                          }
                          $select .= "</select>";
                          echo "<td>$select</td>";
                          echo "<td><input type='number' class='form-control form-control-sm text-center cantidad' value='{$row['cantidad']}' min='1'></td>";
                          echo "<td>".$row['estado']."</td>";
                          echo "<td>
                                  <button class='btn btn-sm btn-warning btn-editar'>Editar</button>
                                  <button class='btn btn-sm btn-danger btn-cancelar'>Cancelar</button>
                                </td>";
                          echo "</tr>";
                      }
                      // ✅ Botón Eliminar toda la orden
                      echo "<tr><td colspan='6' class='text-right'>
                              <button id='btnEliminarOrden' class='btn btn-danger mt-3' data-id_orden='{$id_orden}'>
                                <i class='fas fa-trash-alt'></i> Eliminar toda la orden
                              </button>
                            </td></tr>";
                  } else {  
                      echo "<tr><td colspan='6'>No se encontró la orden con ID $id</td></tr>";
                  }
              } 
            ?>
          </tbody>
				</table>
            </div>
          </div>
        </div>
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Sistema 2025 | D'licias Fast Food</span>
            </div>
          </div>
        </footer>
      </div>
    </div>
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header" style="background-color:#feefc4; color:black;">
            <h5 class="modal-title" id="exampleModalLabel">¿Realmente desea cerrar la sesión?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Seleccione "Cerrar sesión" a continuación si está listo para finalizar su sesión actual.</div>
          <div class="modal-footer">
            <button class="btn btn-warning" type="button" data-dismiss="modal">Cancelar</button>
            <a class="btn btn-danger" href="logout.php">Cerrar Seción</a>
          </div>
        </div>
      </div>
    </div>

    <!-- JS -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/sb-admin.min.js"></script>

    <script type="text/javascript">
      const isSearching = new URLSearchParams(window.location.search).has('searchOrder');
      if (!isSearching) {
        $(document).ready(function () {
          refreshTableOrder();
          setInterval(function () {
            refreshTableOrder();
          }, 3000);
        });
      }
      function refreshTableOrder() {
        $("#tblBodyCurrentOrder").load("displayorder.php?cmd=currentorder");
      }
      $(document).ready(function () {
        $(document).on("click", ".btn-editar", function () {
          const fila = $(this).closest("tr");
          const id_detalle = fila.data("id_detalle");
          const nuevaCantidad = fila.find(".cantidad").val();
          const nuevoArticulo = fila.find(".articulo").val();
          const nuevoPrecio = fila.find(".articulo option:selected").data("precio");
          $.post("editcancelorder.php", {
            action: "editar",
            id_detalle: id_detalle,
            nuevaCantidad: nuevaCantidad,
            nuevoArticulo: nuevoArticulo,
            nuevoPrecio: nuevoPrecio
          }, function (res) {
            alert("Pedido actualizado correctamente");
            location.reload();
          });
        });

        $(document).on("click", ".btn-cancelar", function () {
          if (!confirm("¿Estás seguro de cancelar esta orden?")) return;
          const fila = $(this).closest("tr");
          const id_detalle = fila.data("id_detalle");
          $.post("editcancelorder.php", {
            action: "cancelar",
            id_detalle: id_detalle
          }, function (res) {
            alert("Pedido cancelado correctamente");
            location.reload();
          });
        });

        // Eliminar toda la orden con doble confirmación
        $(document).on("click", "#btnEliminarOrden", function () {
          const id_orden = $(this).data("id_orden");
          Swal.fire({
            title: "¿Eliminar toda la orden?",
            text: "Esta acción eliminará completamente todos los productos de la orden #" + id_orden,
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#d33",
            cancelButtonColor: "#3085d6",
            confirmButtonText: "Sí, eliminar",
            cancelButtonText: "Cancelar",
            backdrop: true
          }).then((result) => {
            if (result.isConfirmed) {
              if (!confirm("Esta acción eliminará por completo la orden. ¿Estás totalmente seguro?")) return;
              $.post("editcancelorder.php", {
                action: "eliminarOrden",
                id_orden: id_orden
              }, function (res) {
                Swal.fire({
                  title: "Orden eliminada",
                  text: "La orden #" + id_orden + " ha sido eliminada correctamente.",
                  icon: "success",
                  timer: 2500,
                  showConfirmButton: false
                });
                setTimeout(() => location.reload(), 2500);
              }).fail(function () {
                alert("Error al eliminar la orden. Inténtalo de nuevo.");
              });
            }
          });
        });
      });
    </script>
  </body>
</html>