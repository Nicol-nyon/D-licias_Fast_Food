var isSearching = false;
var intervalId = null;

$( document ).ready(function() {
  refreshTableOrder();
  intervalId = setInterval(function(){ refreshTableOrder(); }, 3000);

  $("#searchOrderId").keypress(function(event) {
    if (event.which == 13) {
      searchOrder();
    }
  });

  $("#searchButton").click(function() {
    searchOrder();
  });

  $("#clearButton").click(function() {
    $("#searchOrderId").val("");
    refreshTableOrder();
    isSearching = false;
    intervalId = setInterval(function(){ refreshTableOrder(); }, 3000);
  });
});

function refreshTableOrder() {
  if (!isSearching) {
    $( "#tblBodyCurrentOrder" ).load( "displayorder.php?cmd=currentorder" );
  }
}

function searchOrder() {
  clearInterval(intervalId);
  isSearching = true;
  var orderId = $("#searchOrderId").val();
  if (orderId != "") {
    $.ajax({
      url: "displayorder.php",
      type: "GET",
      data: {
        cmd: "searchOrder",
        orderId: orderId
      },
      success: function(output) {
        $("#tblBodyCurrentOrder").html(output);
      }
    });
  } else {
    $( "#tblBodyCurrentOrder" ).load( "displayorder.php?cmd=currentorder" );
    isSearching = false;
    intervalId = setInterval(function(){ refreshTableOrder(); }, 3000);
  }
}

function editStatus (objBtn,orderID) {
  var status = objBtn.value;

  $.ajax({
    url : "editstatus.php",
    type : 'POST',
    data : {
      orderID : orderID,
      status : status 
    },

    success : function(output) {
      isSearching = false;
      intervalId = setInterval(function(){ refreshTableOrder(); }, 3000);
      refreshTableOrder();
    }
  });
}