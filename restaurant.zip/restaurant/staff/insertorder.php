<?php
	include("../functions.php");
	if((!isset($_SESSION['uid']) && !isset($_SESSION['username']) && isset($_SESSION['user_level'])) ) 
		header("Location: login.php");
	if($_SESSION['user_level'] != "staff")
		header("Location: login.php");
	if (empty($_POST['itemID']) || count($_POST['itemID']) == 0) {
		echo "<script>
		Swal.fire({
			icon: 'error',
			title: 'Error',
			text: 'El pedido está vacío. No se registró ninguna orden.',
			confirmButtonText: 'Entendido'
		}).then(() => {
			window.location.href = 'order.php';
		});
		</script>";
		exit();
	}
	if (isset($_POST['sentorder'])) {
		if (isset($_POST['sentorder'])) {
			if (isset($_POST['itemID']) && isset($_POST['itemqty'])) {
				$arrItemID = $_POST['itemID'];
				$arrItemQty = $_POST['itemqty'];
				$specification = isset($_POST['specification']) ? $sqlconnection->real_escape_string($_POST['specification']) : "";
				$tipo_pedido = isset($_POST['tipo_pedido']) ? $sqlconnection->real_escape_string($_POST['tipo_pedido']) : "";
				if (count($arrItemID) == count($arrItemQty)) {
					$arrlength = count($arrItemID);
					$currentOrderID = getLastID("id_orden", "orden_pedido") + 1;
					insertOrderQuery($currentOrderID, $specification, $tipo_pedido);
					for ($i = 0; $i < $arrlength; $i++) {
						insertOrderDetailQuery($currentOrderID, $arrItemID[$i], $arrItemQty[$i]);
					}
					header("Location: index.php");
					exit();
				} else {
					echo "Cantidad de ítems y cantidades no coinciden.";
				}
			}
		}
	}
	function insertOrderDetailQuery($orderID, $itemID, $quantity) {
		global $sqlconnection;
		$query = "SELECT precio FROM articulo WHERE id_articulo = '{$itemID}'";
		$result = $sqlconnection->query($query);

		if ($result && $result->num_rows > 0) {
			$row = $result->fetch_assoc();
			$precio = $row['precio'];
			$insert = "
				INSERT INTO detalle_pedido (id_orden, id_articulo, cantidad, precio_unitario)
				VALUES ('{$orderID}', '{$itemID}', {$quantity}, {$precio})
			";
			if (!$sqlconnection->query($insert)) {
				error_log("Error en detalle_pedido: " . $sqlconnection->error);
			}
		} else {
			error_log("No se encontró el artículo con ID {$itemID}.");
		}
	}
	function insertOrderQuery($orderID, $specification, $tipo_pedido) {
		global $sqlconnection;
		$empleadoID = $_SESSION['uid'];
		$spec = $sqlconnection->real_escape_string($specification);
		$tipo = $sqlconnection->real_escape_string($tipo_pedido);
		$addOrderQuery = "
			INSERT INTO orden_pedido (id_orden, estado, fecha, id_empleado, specification, tipo)
			VALUES ('{$orderID}', 'Espera', NOW(), '{$empleadoID}', '{$spec}', '{$tipo}')
		";
		if ($sqlconnection->query($addOrderQuery) === TRUE) {
			echo "inserted.";
		} else {
			echo "Error al insertar en orden_pedido: ";
			echo $sqlconnection->error;
		}
	}
?>
