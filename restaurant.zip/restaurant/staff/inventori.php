<?php
	include("../functions.php");
  if((!isset($_SESSION['uid']) && !isset($_SESSION['username']) && isset($_SESSION['user_level'])) ) 
    header("Location: login.php");
  if($_SESSION['user_level'] != "staff")
    header("Location: login.php");
  if($_SESSION['user_role'] != "Mesero"){
    echo ("<script>window.alert('Solo meseros disponibles!'); window.location.href='index.php';</script>");
    exit();
  }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Inventario - D'licias Fast Food Empleado</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <link href="css/sb-admin.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  </head>
  <body id="page-top">
    <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
      <a class="navbar-brand mr-1" href="index.php">D'licias Fast Food</a>
      <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
        <i class="fas fa-bars"></i>
      </button>
    </nav>
    <div id="wrapper">
      <ul class="sidebar navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="index.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Panel de Control</span>
          </a>
        </li>
        <?php
          if ($_SESSION['user_role'] == "Mesero") {
            echo '
            <li class="nav-item">
              <a class="nav-link" href="order.php">
                <i class="fas fa-fw fa-book"></i>
                <span>Órden de Pedido</span></a>
            </li>
            <li class="nav-item nav-item-active">
              <a class="nav-link" href="inventori.php">
                <i class="fas fa-fw fa-boxes"></i>
                <span>Inventario</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="ediorder.php">
                <i class="fas fa-edit"></i>
                <span>Busqueda y Edicion</span>
              </a>
            </li>
          ';
          }
          if ($_SESSION['user_role'] == "Chef") {
            echo '
            <li class="nav-item">
              <a class="nav-link" href="kitchen.php">
                <i class="fas fa-fw fa-utensils"></i>
                <span>Kitchen</span></a>
            </li>
            ';
          }
        ?>
        <?php include("accesibilidad.php"); ?>
        <li class="nav-item">
          <a class="nav-link" href="#" data-toggle="modal" data-target="#logoutModal">
            <i class="fas fa-fw fa-power-off"></i>
            <span>Cerrar Sesión</span>
          </a>
        </li>
      </ul>
      <div id="content-wrapper">
        <div class="container-fluid">
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="index.php">Panel de Control</a>
            </li>
            <li class="breadcrumb-item active">Inventario</li>
          </ol>
          <h1>Inventario de articulos</h1>
          <hr>
          <p>Muestra la lista de categorías junto con los detalles específicos de cada producto.</p>
          <div class="card mb-3 border-primary" style="background-color:#057dcd">
            <div class="card-header" style="color:ghostwhite;">
              <i class="fas fa-utensils"></i> Lista de Categorías
            </div>
            <div class="card-body">
              <?php 
              $menuQuery = "SELECT * FROM categoria_articulo";
              if ($menuResult = $sqlconnection->query($menuQuery)) {
                if ($menuResult->num_rows == 0) {
                  echo "<center><label>No hay categorías registradas.</label></center>";
                }
                while ($menuRow = $menuResult->fetch_array(MYSQLI_ASSOC)) {
                  $idCategoria = $sqlconnection->real_escape_string($menuRow["id_categoria"]);
              ?>
              <div class="card mb-3 border-primary">
                <div class="card-header">
                  <i class="fas fa-bars"></i> <?php echo htmlspecialchars($menuRow["nombre_categoria"]); ?>
                </div>
                <div class="card-body">
                  <table class="table table-bordered table-striped" width="100%" cellspacing="0">
                    <tr>
                      <th class='text-center table-dark'>#</th>
                      <th class='text-center table-dark'>Nombre de la Opción</th>
                      <th class='text-center table-dark'>Precio (PEN)</th>
                      <th class='text-center table-dark'>Disponibilidad</th>
                    </tr>
                    <?php
                    $menuItemQuery = "SELECT * FROM articulo WHERE id_categoria = '$idCategoria'";
                    if ($menuItemResult = $sqlconnection->query($menuItemQuery)) {
                      if ($menuItemResult->num_rows == 0) {
                        echo "<tr><td colspan='4' class='text-center'>Sin productos en esta categoría.</td></tr>";
                      } else {
                        $itemno = 1;
                        while ($menuItemRow = $menuItemResult->fetch_array(MYSQLI_ASSOC)) {
                    ?>
                    <tr>
                      <td><?php echo $itemno++; ?></td>
                      <td><?php echo htmlspecialchars($menuItemRow["nombre"]); ?></td>
                      <td><?php echo number_format($menuItemRow["precio"], 2); ?></td>
                      <td>
                        <?php echo ($menuItemRow["disponibilidad"] == 1) ? "<span class='text-success'>Disponible</span>" : "<span class='text-danger'>No disponible</span>"; ?>
                      </td>
                    </tr>
                    <?php
                        } // while productos
                      } // else productos
                    } else {
                      echo "<tr><td colspan='4'>Error al cargar los articulos: " . $sqlconnection->error . "</td></tr>";
                    }
                    ?>
                  </table>
                </div>
              </div>
              <?php
                } // while categorías
              } else {
                echo "<p>Error al obtener categorías: " . $sqlconnection->error . "</p>";
              }
              ?>
            </div>
          </div>
        </div>
      </div>
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Sistema 2025 | D'licias Fast Food</span>
            </div>
          </div>
        </footer>
      </div>
    </div>
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header" style="background-color:#feefc4; color:black;">
            <h5 class="modal-title" id="exampleModalLabel">¿Realmente desea cerrar la sesión?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Seleccione "Cerrar sesión" a continuación si está listo para finalizar su sesión actual.</div>
          <div class="modal-footer">
            <button class="btn btn-warning" type="button" data-dismiss="modal">Cancelar</button>
            <a class="btn btn-danger" href="logout.php">Cerrar Sesión</a>
          </div>
        </div>
      </div>
    </div>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/sb-admin.min.js"></script>
    <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
	  <script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
	<script>
		var currentItemID = null;
		function displayItem (id) {
			$.ajax({
				url : "displayitem.php",
					type : 'POST',
					data : { btnMenuID : id },

					success : function(output) {
						$("#tblItem").html(output);
					}
				});
		}
		function insertItem () {
			var id = currentItemID;
			var quantity = $("#qty").val();
			$.ajax({
				url : "displayitem.php",
					type : 'POST',
					data : { 
						btnMenuItemID : id,
						qty : quantity 
					},
					success : function(output) {
						$("#tblOrderList").append(output);
						$("#qtypanel").prop('hidden',true);
					}
				});
			$("#qty").val(1);
		}
		function setQty (id) {
			currentItemID = id;
			$("#qtypanel").prop('hidden',false);
		}
		$(document).on('click','.deleteBtn', function(event){
		        event.preventDefault();
		        $(this).closest('tr').remove();
		        return false;
		});
	</script>
  </body>
</html>