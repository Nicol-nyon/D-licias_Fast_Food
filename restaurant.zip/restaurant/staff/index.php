<?php 
  include("../functions.php");
  if (
    (!isset($_SESSION['uid']) || !isset($_SESSION['username']) || !isset($_SESSION['user_level']))
  ) {
    header("Location: login.php");
    exit();
  }
  if ($_SESSION['user_level'] != "staff") {
    header("Location: login.php");
    exit();
  }
  function getStatus () {
    global $sqlconnection;
    $uid = $_SESSION['uid'];
    $query = "SELECT status FROM empleado WHERE id_empleado = '$uid'";
    if ($result = $sqlconnection->query($query)) {
      if ($row = $result->fetch_array(MYSQLI_ASSOC)) {
        return $row['status'];
      }
    } else {
      echo "Error al consultar el estado: " . $sqlconnection->error;
    }
  }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>D'licias Fast Food Empleado</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <link href="css/sb-admin.css" rel="stylesheet">
  </head>
  <body id="page-top">
    <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
      <a class="navbar-brand mr-1" href="index.php">D'licias Fast Food</a>
      <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
        <i class="fas fa-bars"></i>
      </button>
    </nav> 
    <div id="wrapper">
      <ul class="sidebar navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="index.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Panel de Control</span>
          </a>
        </li>
        <?php
          if ($_SESSION['user_role'] == "Mesero") {
            echo '
            <li class="nav-item">
              <a class="nav-link" href="order.php">
                <i class="fas fa-fw fa-book"></i>
                <span>Órden de Pedido</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="inventori.php">
                <i class="fas fa-fw fa-boxes"></i>
                <span>Inventario</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="ediorder.php">
                <i class="fas fa-edit"></i>
                <span>Busqueda y Edición</span>
              </a>
            </li>
          ';
          }
          if ($_SESSION['user_role'] == "Chef") {
            echo '
            <li class="nav-item">
              <a class="nav-link" href="kitchen.php">
                <i class="fas fa-fw fa-utensils"></i>
                <span>Kitchen</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="chefmenu.php">
                <i class="fas fa-fw fa-concierge-bell"></i>
                <span>Disponibilidad de Articulos / Platillos</span></a>
            </li>
            ';
          }
        ?>
        <?php include("accesibilidad.php"); ?>
        <li class="nav-item">
          <a class="nav-link" href="#" data-toggle="modal" data-target="#logoutModal">
            <i class="fas fa-fw fa-power-off"></i>
            <span>Cerrar Sesión</span>
          </a>
        </li>
      </ul>
      <div id="content-wrapper">
        <div class="container-fluid">
          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="index.php">Panel de Control</a>
            </li>
            <li class="breadcrumb-item active">Vista General</li>
          </ol>
          <h1>Panel de Empleado</h1><hr>
          <p>Permite cambiar tu estado entre online, offline y tiempo libre, y visualizar las listas de órdenes más recientes.</p>
          <div class="row">
            <div class="col-lg-9">
              <div class="card mb-3">
                <div class="card-header" style="background-color:#748c9e; color:ghostwhite;">
                  <i class="fas fa-list-ol"></i>
                  Lista de las órdenes más recientes</div>
                <div class="card-body">
                	<table id="orderTable" class="table table-striped table-bordered width="100%" cellspacing="0">
                	</table>
                </div>
                <div class="card-footer small text-muted"><i>Se actualiza cada 3 segundos</i></div>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="card mb-3 text-center">
                <div class="card-header" style="background-color:#b5ea8c; color:black;">
                  <i class="fas fa-chart-bar"></i>
                  Estado
                </div>
                <div class="card-body">
                  Bienvenido, <b><?php echo $_SESSION['username'] ?></b><hr>
                  Cargo: <b><?php echo ucfirst($_SESSION['user_role']) ?></b><hr>
                  <form action="statuschange.php" method="POST">
                    <input type="hidden" id="staffid" name="staffid" value="<?php echo trim($_SESSION['uid']); ?>" />
                    <?php 
                      $currentStatus = getStatus();
                      if ($currentStatus == 'Online') {
                        echo "<input type='submit' class='btn btn-success myBtn' name='btnStatus' value='Online'>";
                      } elseif ($currentStatus == 'Free time') {
                        echo "<input type='submit' class='btn btn-primary myBtn' name='btnStatus' value='Free time'>";
                      } else {
                        echo "<input type='submit' class='btn btn-secondary myBtn' name='btnStatus' value='rest'>";
                      }
                    ?>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Sistema 2025 | D'licias Fast Food</span>
            </div>
          </div>
        </footer>
      </div>
    </div>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>
    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header" style="background-color:#feefc4; color:black;">
            <h5 class="modal-title" id="exampleModalLabel">¿Realmente desea cerrar la sesión?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Seleccione "Cerrar sesión" a continuación si está listo para finalizar su sesión actual.</div>
          <div class="modal-footer">
            <button class="btn btn-warning" type="button" data-dismiss="modal">Cancelar</button>
            <a class="btn btn-danger" href="logout.php">Cerrar Sesión</a>
          </div>
        </div>
      </div>
    </div>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/sb-admin.min.js"></script>
    <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
    <script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
    <script type="text/javascript">
    $( document ).ready(function() {
        refreshTableOrder();
    });
    function refreshTableOrder() {
      $( "#orderTable" ).load( "displayorder.php?cmd=currentready" );
    }
    //refresh order current list every 3 secs
    setInterval(function(){ refreshTableOrder(); }, 3000);
  </script>
  </body>
</html>