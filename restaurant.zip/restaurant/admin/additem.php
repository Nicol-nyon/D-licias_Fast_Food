<?php
	if (isset($_POST['addItem'])) {
		if (!empty($_POST['itemName']) && !empty($_POST['itemPrice']) && !empty($_POST['menuID'])) {
			$nombre = $sqlconnection->real_escape_string($_POST['itemName']);
			$precio = $sqlconnection->real_escape_string($_POST['itemPrice']);
			$id_categoria = $sqlconnection->real_escape_string($_POST['menuID']);
			$addItemQuery = "INSERT INTO articulo (nombre, precio, id_categoria) 
							VALUES ('{$nombre}', {$precio}, '{$id_categoria}')";
			if ($sqlconnection->query($addItemQuery) === TRUE) {
				header("Location: menu.php"); 
				exit();
			} else {
				echo "Error al agregar artículo: " . $sqlconnection->error;
			}
		} else {
			echo "Todos los campos son obligatorios.";
		}
	}
?>