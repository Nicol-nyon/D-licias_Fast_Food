<?php 
  include("../functions.php");
  if((!isset($_SESSION['uid']) && !isset($_SESSION['username']) && isset($_SESSION['user_level'])) ) 
    header("Location: login.php");
  if($_SESSION['user_level'] != "admin")
    header("Location: login.php");
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Caja - D'licias Fast Food Admin</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <link href="css/sb-admin.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  </head>

  <body id="page-top">
    <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
      <a class="navbar-brand mr-1" href="index.php">D'licias Fast Food</a>
      <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
        <i class="fas fa-bars"></i>
      </button>
    </nav>

    <div id="wrapper">
      <ul class="sidebar navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="index.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Panel de Control</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="menu.php">
            <i class="fas fa-fw fa-utensils"></i>
            <span>Menú</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="payments.php">
            <i class="fas fa-coins"></i>
            <span>Caja</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="sales.php">
            <i class="fas fa-money-check-alt"></i>
            <span>Ventas</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="dashboard.php">
            <i class="fas fa-chart-area"></i>
            <span>Estadística</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="staff.php">
            <i class="fas fa-fw fa-user-circle"></i>
            <span>Empleados</span>
          </a>
        </li>
        <?php include("accesibilidad.php"); ?>
        <li class="nav-item">
          <a class="nav-link" href="#" data-toggle="modal" data-target="#logoutModal">
            <i class="fas fa-fw fa-power-off"></i>
            <span>Cerrar Sesión</span>
          </a>
        </li>
        
      </ul>

      <div id="content-wrapper">
        <div class="container-fluid">
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="index.php">Panel de Control</a>
            </li>
            <li class="breadcrumb-item active">Caja</li>
          </ol>
          <!-- Page Content -->
          <h1>Procesar Pago</h1>
          <hr>
          <p>Ingrese el número de orden para iniciar el proceso de pago.</p>
          <div class="row">
            <!-- Columna Izquierda: Formulario -->
            <div class="col-lg-8">
              <div class="card mb-3">
                <div class="card-header" style="background-color:#6986bd; color:white;">
                  <i class="fas fa-file-invoice-dollar"></i> <strong>Ingreso de Orden</strong>
                </div>
                <div class="card-body">
                  <form id="formPago" method="POST" action="processpayments.php">

                    <div class="form-row">
                      <div class="form-group col-md-6">
                        <label for="tipoComprobante">Tipo de Comprobante</label>
                        <select class="form-control form-control-sm" name="tipoComprobante" id="tipoComprobante" required>
                          <option value="boleta" selected>Boleta</option>
                          <option value="factura">Factura</option>
                          <option value="Boleta electronica">Boleta Electronica</option>
                        </select>
                      </div>

                      <div class="form-group col-md-6">
                        <label for="codigoOrden">Código de Orden</label>
                        <input type="number" name="codigoOrden" id="codigoOrden" class="form-control" required>
                      </div>
                    </div>

                    <div class="form-row">
                      <div class="form-group col-md-6">
                        <label for="metodoPago">Método de Pago</label>
                        <select name="metodoPago" id="metodoPago" class="form-control" required>
                          <option value="">-- Seleccionar --</option>
                          <?php
                            $metodoQuery = "SELECT id_metodo, descripcion FROM metodo_pago";
                            if ($metodos = $sqlconnection->query($metodoQuery)) {
                              while ($met = $metodos->fetch_assoc()) {
                                echo "<option value='{$met['id_metodo']}'>{$met['descripcion']}</option>";
                              }
                            }
                          ?>
                        </select>
                      </div>

                      <div class="form-group col-md-6">
                        <label for="nombreCliente">Nombre del Cliente</label>
                        <input type="text" name="nombreCliente" id="nombreCliente" class="form-control">
                      </div>
                    </div>

                    <div class="form-row">
                      <div class="form-group col-md-3">
                        <label for="tipoDocumento">Tipo Doc.</label>
                        <select name="tipoDocumento" id="tipoDocumento" class="form-control">
                          <option value="">-- Tipo --</option>
                          <option value="DNI">DNI</option>
                          <option value="RUC">RUC</option>
                          <option value="CE">Carnet Ext.</option>
                          <option value="PAST">Pasaporte</option>
                        </select>
                      </div>

                      <div class="form-group col-md-3">
                        <label for="numeroDocumento">N° Documento</label>
                        <input type="text" name="numeroDocumento" id="numeroDocumento" class="form-control">
                      </div>

                      <div class="form-group col-md-6">
                        <label for="monto">Monto (S/.)</label>
                        <input type="number" step="0.1" name="monto" id="monto" class="form-control" required>
                      </div>
                    </div>

                    <div class="form-group">
                      <label for="detalleDescripcion">Detalle del Pago</label>
                      <textarea name="detalleDescripcion" id="detalleDescripcion" class="form-control" rows="2" placeholder="Ej. Pago total"></textarea>
                    </div>

                    <button type="submit" class="btn btn-success btn-block">
                      Procesar Pago
                    </button>
                  </form>
                </div>
                <div class="card-footer small text-muted">
                  Asegúrese de ingresar los datos correctamente antes de procesar el pago.
                </div>
              </div>
            </div>

            <!-- Columna Derecha: Detalles del Pedido + Ayuda Rápida -->
            <div class="col-lg-4">
              <!-- Detalles del Pedido -->
              <div class="card mb-3" id="detalleOrdenCard" style="display: none;">
                <div class="card-header">
                  <i class="fas fa-receipt"></i> Detalles del Pedido
                </div>
                <div class="card-body" id="detalleOrdenBody">
                  <!-- Se carga dinámicamente con JS -->
                </div>
              </div>

              <!-- Ayuda Rápida -->
              <div class="card mb-3">
                <div class="card-header" style="background-color:#47595b; color:white;">
                  <i class="fas fa-info-circle"></i> <strong>Ayuda Rápida</strong>
                </div>
                <div class="card-body">
                  <ul>
                    <li>Verifique que la orden esté completada antes de procesar el pago.</li>
                    <li>Seleccione el método de pago adecuado.</li>
                    <li>Puede agregar un detalle explicativo del pago.</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

        <!-- /.container-fluid -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright &copy; Sistema 2025 | D'licias Fast Food</span>
            </div>
          </div>
        </footer>
      </div>
    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header" style="background-color:#feefc4; color:black;">
            <h5 class="modal-title" id="exampleModalLabel">¿Realmente desea cerrar la sesión?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Seleccione "Cerrar sesión" a continuación si está listo para finalizar su sesión actual.</div>
          <div class="modal-footer">
            <button class="btn btn-warning" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-danger" href="logout.php">Cerrar Sesión</a>
          </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>

    <script type="text/javascript">

    $(document).ready(function () {

      $(".btn-editar").on("click", function () {
        const fila = $(this).closest("tr");
        const id_detalle = fila.data("id_detalle");
        const nuevaCantidad = fila.find(".cantidad").val();
        const nuevoArticulo = fila.find(".articulo").val();
        const nuevoPrecio = fila.find(".articulo option:selected").data("precio");

        $.post("editcancelorder.php", {
          action: "editar",
          id_detalle: id_detalle,
          nuevaCantidad: nuevaCantidad,
          nuevoArticulo: nuevoArticulo,
          nuevoPrecio: nuevoPrecio
        }, function (res) {
          alert("Pedido actualizado correctamente");
          location.reload();
        });
      });

      $(".btn-cancelar").on("click", function () {
        if (!confirm("¿Estás seguro de cancelar esta orden?")) return;
        const fila = $(this).closest("tr");
        const id_detalle = fila.data("id_detalle");

        $.post("editcancelorder.php", {
          action: "cancelar",
          id_detalle: id_detalle
        }, function (res) {
          alert("Pedido cancelado correctamente");
          location.reload();
        });
      });

      $("#formPago").on("submit", function (e) {
        e.preventDefault();

        $.ajax({
          url: "processpayments.php",
          method: "POST",
          data: $(this).serialize(),
          dataType: "json",
          success: function (response) {
            if (response.success) {
              Swal.fire({
                icon: 'success',
                title: 'Pago exitoso',
                text: response.message
              }).then(() => {
                location.reload();
              });
            } else {
              Swal.fire({
                icon: 'error',
                title: 'Error',
                text: response.message || 'Ocurrió un error inesperado.'
              });
            }
          },
          error: function (xhr) {
            Swal.fire({
              icon: 'error',
              title: 'Error en el servidor',
              text: xhr.responseText
            });
          }
        });
      });

    });

  </script>
  <script>
    document.getElementById('codigoOrden').addEventListener('input', function () {
      let codigo = this.value;

      if (codigo.trim() !== '') {
        fetch('get_order_details.php?orden=' + codigo)
          .then(response => response.json())
          .then(data => {
            const card = document.getElementById('detalleOrdenCard');
            const body = document.getElementById('detalleOrdenBody');

            if (data.success) {
              let html = `
                <p><strong>Fecha:</strong> ${data.fecha}</p>
                <p><strong>Estado:</strong> ${data.estado}</p>  
                <ul>`;
              data.articulos.forEach(item => {
                html += `<li>${item.cantidad} × ${item.nombre} (S/. ${item.precio_unitario})</li>`;
              });
              html += `</ul>
                <p><strong>Total:</strong> S/. ${data.monto_total}</p>`;
              
              card.style.display = 'block';
              body.innerHTML = html;

              document.getElementById('monto').value = data.monto_total;
              document.getElementById('detalleDescripcion').value = "Pago total";

            } else {
              card.style.display = 'block';
              body.innerHTML = `<div class="text-danger">${data.message}</div>`;
              document.getElementById('monto').value = '';
            }
          });
      } else {
        document.getElementById('detalleOrdenCard').style.display = 'none';
        document.getElementById('monto').value = '';
      }
    });

    document.addEventListener("DOMContentLoaded", function () {
      const tipoComprobante = document.getElementById("tipoComprobante");
      const nombreCliente = document.getElementById("nombreCliente");
      const tipoDocumento = document.getElementById("tipoDocumento");
      const numeroDocumento = document.getElementById("numeroDocumento");

      function toggleCamposCliente() {
        const tipo = tipoComprobante.value;

        if (tipo === "factura") {
          // Factura: campos obligatorios y tipo de documento fijo
          nombreCliente.readOnly = false;
          numeroDocumento.readOnly = false;
          tipoDocumento.disabled = true;

          nombreCliente.required = false;
          numeroDocumento.required = false;
          tipoDocumento.required = false;

          nombreCliente.value = "Nombre de cliente (obligatorio)";
          tipoDocumento.value = "RUC";
          numeroDocumento.value = "";

        } else if (tipo === "Boleta electronica") {
          // Boleta Electrónica: se comporta como Boleta
          nombreCliente.readOnly = false;
          numeroDocumento.readOnly = false;
          tipoDocumento.disabled = false;

          nombreCliente.required = false;
          numeroDocumento.required = false;
          tipoDocumento.required = false;

          nombreCliente.value = "Nombre de cliente (opcional)";
          tipoDocumento.value = "";
          numeroDocumento.value = "";

        } else {
          // Boleta normal
          nombreCliente.readOnly = false;
          numeroDocumento.readOnly = true;
          tipoDocumento.disabled = true;

          nombreCliente.required = false;
          numeroDocumento.required = false;
          tipoDocumento.required = false;

          nombreCliente.value = "Nombre de cliente (opcional)";
          tipoDocumento.value = "";
          numeroDocumento.value = "";
        }
      }
      
      tipoComprobante.addEventListener("change", toggleCamposCliente);

      // Ejecutar al cargar la página
      toggleCamposCliente();
    });
  </script>

  </body>
</html>