<?php
	include("../functions.php");
	if (
		(!isset($_SESSION['uid']) || !isset($_SESSION['username']) || !isset($_SESSION['user_level']))
	) {
		header("Location: login.php");
		exit();
	}
	if ($_SESSION['user_level'] != "admin") {
		header("Location: login.php");
		exit();
	}
	if (isset($_POST['id_empleado'])) {
		$id_empleado = $sqlconnection->real_escape_string($_POST['id_empleado']);
		$deleteStaffQuery = "DELETE FROM empleado WHERE id_empleado = '$id_empleado'";
		if ($sqlconnection->query($deleteStaffQuery) === TRUE) {
			header("Location: staff.php"); 
			exit();
		} else {
			echo "Error al eliminar: " . $sqlconnection->error;
		}
	}
?>