<?php 
    include("../functions.php");

    if (isset($_POST['username']) && isset($_POST['password'])) {

        $username = $sqlconnection->real_escape_string($_POST['username']);
        $password = $sqlconnection->real_escape_string($_POST['password']);

        $sql = "SELECT * FROM empleado 
                WHERE nombre = '$username' AND password = '$password' AND cargo = 'admin'";

        if ($result = $sqlconnection->query($sql)) {

            if ($row = $result->fetch_array(MYSQLI_ASSOC)) {
                
                $uid = $row['id_empleado'];
                $nombre_usuario = $row['nombre'];

                $_SESSION['uid'] = $uid;
                $_SESSION['username'] = $nombre_usuario;
                $_SESSION['user_level'] = "admin";

                echo "correct";
                //Cambia el estado del empleado a "Online" al Ser correcta la contraseña
                $uid = $_SESSION['uid'];
                $sqlconnection->query("UPDATE empleado SET status = 'Online' WHERE id_empleado = '$uid'");

            } else {
                echo "❌ Usuario o contraseña incorrectos.";
            }

        } else {
            echo "❌ Error en la consulta: " . $sqlconnection->error;
        }
    } else {
        echo "❗ Faltan datos de inicio de sesión.";
    }
?>
