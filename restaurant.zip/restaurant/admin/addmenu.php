<?php
	if (isset($_POST['addmenu'])) {
		if (!empty($_POST['nombre_categoria'])) {
			$nombreCategoria = $sqlconnection->real_escape_string($_POST['nombre_categoria']);
			$idCategoria = strtoupper(substr($nombreCategoria, 0, 3));
			$checkQuery = "SELECT id_categoria FROM categoria_articulo WHERE id_categoria = '{$idCategoria}'";
			$result = $sqlconnection->query($checkQuery);
			if ($result->num_rows > 0) {
				$idCategoria .= rand(10,99);
			}
			$addCategoriaQuery = "INSERT INTO categoria_articulo (id_categoria, nombre_categoria) VALUES ('{$idCategoria}', '{$nombreCategoria}')";
			if ($sqlconnection->query($addCategoriaQuery) === TRUE) {
				header("Location: menu.php");
				exit();
			} else {
				echo "Error al agregar la categoría: " . $sqlconnection->error;
			}
		} else {
			echo "Por favor, ingrese un nombre para la categoría.";
		}
	}
?>
