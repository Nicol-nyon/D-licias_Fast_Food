<?php 
	include("../functions.php");
    if((isset($_SESSION['uid']) && isset($_SESSION['username']) && isset($_SESSION['user_level'])) )  {
        if($_SESSION['user_level'] == "admin") {
          header("Location: index.php");
        }
    }
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<title>Ingreso - Administrador</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;700&display=swap" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
	<!-- Estilos personalizados -->
	<style>
		body {
			background: linear-gradient(120deg, #2c3e50, #3498db);
			font-family: 'Nunito', sans-serif;
			height: 100vh;
			display: flex;
			align-items: center;
			justify-content: center;
		}
		.card {
			border: none;
			border-radius: 15px;
			box-shadow: 0 8px 30px rgba(0,0,0,0.3);
			width: 100%;
			max-width: 400px;
		}
		h1.branding {
			text-align: center;
			color: white;
			margin-bottom: 2rem;
			text-shadow: 2px 2px 5px rgba(0,0,0,0.5);
		}
		.card-header {
			background-color: #2980b9;
			color: white;
			font-size: 1.5rem;
			font-weight: bold;
			text-align: center;
			border-top-left-radius: 15px;
			border-top-right-radius: 15px;
		}
		.form-control:focus {
			border-color: #3498db;
			box-shadow: 0 0 0 0.25rem rgba(52,152,219,.25);
		}
		.btn-primary {
			background-color: #2980b9;
			border: none;
			transition: 0.3s;
		}
		.btn-primary:hover {
			background-color: #1c5980;
		}
		#warningbox {
			margin-top: 10px;
		}
		.btn-secondary {
		background-color:rgb(241, 60, 60);
		border: none;
		color: white;
		transition: 0.3s;
		}
		.btn-secondary:hover {
		background-color:rgba(248, 61, 61, 0.83);
		}
	</style>
</head>
<body>
	<div class="container">
		<h1 class="branding">D'Licias Fast Food</h1>
		<div class="card mx-auto">
			<div class="card-header">Ingreso de Administrador</div>
			<div class="card-body">
				<form id="loginform">
					<div class="mb-3">
						<label for="inputUsername" class="form-label">Usuario</label>
						<input type="text" class="form-control" id="inputUsername" name="username" required autofocus>
					</div>
					<div class="mb-3">
						<label for="inputPassword" class="form-label">Contraseña</label>
						<input type="password" class="form-control" id="inputPassword" name="password" required>
					</div>
					<div id="warningbox"></div>
					<button type="submit" class="btn btn-primary w-100">Ingresar</button>
				</form>
					<hr>
					<a href="../index.php" class="btn btn-secondary w-100 fw-bold">Volver al Inicio</a>
				</div>
		</div>
	</div>
	<!-- JavaScript -->
	<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
	<script>
		$('#loginform').submit(function(e) {
			e.preventDefault();
			$.ajax({
				type: "POST",
				url: 'process.php',
				data: {
					username: $("#inputUsername").val(),
					password: $("#inputPassword").val()
				},
				success: function(response) {
					if (response.trim() === 'correct') {
						window.location.href = 'index.php';
					} else {
						$("#warningbox").html("<div class='alert alert-danger'>"+response+"</div>");
					}
				},
				error: function() {
					$("#warningbox").html("<div class='alert alert-danger'>Error de conexión. Intenta nuevamente.</div>");
				}
			});
		});
	</script>
</body>
</html>