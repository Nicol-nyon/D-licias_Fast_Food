<?php 
include("../functions.php");

date_default_timezone_set('America/Lima');

if (!isset($_SESSION['uid']) || !isset($_SESSION['username']) || !isset($_SESSION['user_level'])) {
    header("Location: login.php");
    exit();
}

if ($_SESSION['user_level'] != "admin" && $_SESSION['user_level'] != "staff") {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_orden = intval($_POST['codigoOrden'] ?? 0);
    $id_metodo = $_POST['metodoPago'] ?? '';
    $descripcion = trim($_POST['detalleDescripcion'] ?? '');
    $monto = floatval($_POST['monto'] ?? 0);
    $id_empleado = $_SESSION['uid'];
    $nombre_cliente = trim($_POST['nombreCliente'] ?? '');
    $tipo_documento = $_POST['tipoDocumento'] ?? '';
    $numero_documento = trim($_POST['numeroDocumento'] ?? '');
    $tipo_comprobante = trim($_POST['tipoComprobante'] ?? '');

    if ($id_orden <= 0 || $monto <= 0 || $id_metodo == '' || $tipo_comprobante == '') {
        die("Error: Faltan datos obligatorios generales.");
    }

    if ($tipo_comprobante == 'factura') {
        $tipo_documento = 'RUC';
        if ($nombre_cliente == '' || $numero_documento == '') {
            die("Error: Faltan datos del cliente para la factura.");
        }
    } else {
        $nombre_cliente = "Consumidor Final";
        $tipo_documento = null;
        $numero_documento = null;
    }

    $verificarOrden = $sqlconnection->prepare("SELECT estado FROM orden_pedido WHERE id_orden = ?");
    $verificarOrden->bind_param("i", $id_orden);
    $verificarOrden->execute();
    $result = $verificarOrden->get_result();

    if ($result->num_rows == 0) {
        die("Error: La orden no existe.");
    }

    $estadoOrden = $result->fetch_assoc()['estado'];
    if ($estadoOrden != 'Entregado') {
        die("Error: Solo se pueden pagar órdenes con estado 'Entregado'.");
    }

    // Insertar comprobante
    $stmt1 = $sqlconnection->prepare("
        INSERT INTO comprobante_pago 
        (id_orden, id_empleado, fecha_emision, tipo_comprobante, nombre_cliente, tipo_documento, numero_documento)
        VALUES (?, ?, NOW(), ?, ?, ?, ?)
    ");
    $stmt1->bind_param("isssss", $id_orden, $id_empleado, $tipo_comprobante, $nombre_cliente, $tipo_documento, $numero_documento);

    if (!$stmt1->execute()) {
        die("Error al registrar el comprobante: " . $stmt1->error);
    }

    $id_comprobante = $stmt1->insert_id;

    // Insertar detalle del comprobante
    $stmt2 = $sqlconnection->prepare("
        INSERT INTO detalle_comprobante (id_comprobante, id_metodo, descripcion, monto)
        VALUES (?, ?, ?, ?)
    ");
    $stmt2->bind_param("issd", $id_comprobante, $id_metodo, $descripcion, $monto);

    if (!$stmt2->execute()) {
        echo json_encode(["success" => false, "message" => "Error al registrar detalle."]);
        exit();
    }

    // Obtener método de pago
    $queryMetodo = $sqlconnection->prepare("SELECT descripcion FROM metodo_pago WHERE id_metodo = ?");
    $queryMetodo->bind_param("i", $id_metodo);
    $queryMetodo->execute();
    $resMetodo = $queryMetodo->get_result();
    $nombreMetodo = $resMetodo->fetch_assoc()['descripcion'] ?? 'Desconocido';






    // --- GENERAR PDF --- //
    require('../libs/fpdf182/fpdf.php');
    $pdf = new FPDF();
    $pdf->AddPage();

    // Encabezado
    if (file_exists('../assets/logo.png')) {
        $pdf->Image('../assets/logo.png', 10, 10, 30);
    }
    $pdf->SetFont('Arial', 'B', 16);
    $pdf->Cell(0, 10, utf8_decode('Comprobante de Pago Electrónico'), 0, 1, 'C');
    $pdf->Ln(5);

    // Datos de la empresa
    $pdf->SetFont('Arial', '', 11);
    $pdf->Cell(0, 6, utf8_decode("EMPRESA: D'LICIAS FAST FOOD"), 0, 1, 'C');
    $pdf->Cell(0, 6, utf8_decode('RUC: 10732128609'), 0, 1, 'C');
    $pdf->Cell(0, 6, utf8_decode('Dirección: Calle Paula Quiroz 299, Sta. Luzmila - Comas'), 0, 1, 'C');
    $pdf->Cell(0, 6, utf8_decode('Cel: 977-842-812'), 0, 1, 'C');
    $pdf->Ln(4);

    // Línea separadora
    $pdf->SetDrawColor(150, 150, 150);
    $pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
    $pdf->Ln(6);

    // Datos del comprobante
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(95, 7, utf8_decode('Tipo de Comprobante: ' . strtoupper($tipo_comprobante)), 0, 0);
    $pdf->Cell(95, 7, 'Fecha: ' . date('d/m/Y'), 0, 1);
    $pdf->SetFont('Arial', '', 12);
    
    // Factura usa el número de ORDEN, Boleta el número de COMPROBANTE
    if ($tipo_comprobante == 'factura') {
        $numero_comprobante = 'FAC-' . str_pad($id_orden, 6, '0', STR_PAD_LEFT);
    } else {
        $numero_comprobante = 'BOL-' . str_pad($id_orden, 6, '0', STR_PAD_LEFT);
    }

    $pdf->Cell(95, 7, utf8_decode('Número de Orden: ' . $numero_comprobante), 0, 0);
    $pdf->Cell(95, 7, utf8_decode('Método de Pago: ' . $nombreMetodo), 0, 1);
    $pdf->Ln(5);

    // Datos del cliente
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 7, 'Datos del Cliente', 0, 1);
    $pdf->SetFont('Arial', '', 12);
    if ($tipo_comprobante == 'factura') {
        $pdf->Cell(60, 7, utf8_decode('Nombre / Razón Social: ' . $nombre_cliente), 0, 1);
        $pdf->Cell(60, 7, utf8_decode('RUC: ' . $numero_documento), 0, 1);
        $pdf->Cell(60, 7, utf8_decode('Dirección: (No especificada)'), 0, 1);
    } else {
        $pdf->Cell(60, 7, utf8_decode('Nombre: ' . $nombre_cliente), 0, 1);
    }
    $pdf->Ln(5);

    // Tabla de productos
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->SetFillColor(230, 230, 230);
    $pdf->Cell(80, 10, 'Producto', 1, 0, 'C', true);
    $pdf->Cell(30, 10, 'Cantidad', 1, 0, 'C', true);
    $pdf->Cell(40, 10, 'Precio Unitario', 1, 0, 'C', true);
    $pdf->Cell(40, 10, 'Total', 1, 1, 'C', true);

    $pdf->SetFont('Arial', '', 11);
    $queryDetalle = "
        SELECT a.nombre, SUM(dp.cantidad) AS cantidad, dp.precio_unitario
        FROM detalle_pedido dp
        JOIN articulo a ON dp.id_articulo = a.id_articulo
        WHERE dp.id_orden = ?
        GROUP BY a.nombre, dp.precio_unitario
    ";
    $stmtDetalle = $sqlconnection->prepare($queryDetalle);
    $stmtDetalle->bind_param("i", $id_orden);
    $stmtDetalle->execute();
    $resultDetalle = $stmtDetalle->get_result();

    $total = 0;
    if ($resultDetalle && $resultDetalle->num_rows > 0) {
        while ($row = $resultDetalle->fetch_assoc()) {
            $subtotal = $row['cantidad'] * $row['precio_unitario'];
            $total += $subtotal;
            $pdf->Cell(80, 8, utf8_decode($row['nombre']), 1);
            $pdf->Cell(30, 8, $row['cantidad'], 1, 0, 'C');
            $pdf->Cell(40, 8, 'S/. ' . number_format($row['precio_unitario'], 2), 1, 0, 'C');
            $pdf->Cell(40, 8, 'S/. ' . number_format($subtotal, 2), 1, 1, 'C');
        }
    } else {
        $pdf->Cell(0, 10, 'No hay detalles.', 1, 1, 'C');
    }

    // Calcular IGV (18%)
    $igv = $total * 0.18;
    $totalConIgv = $total;

    // Totales
    $pdf->Ln(5);
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(50, 8, 'Subtotal:', 0, 0, 'R');
    $pdf->Cell(240, 8, 'S/. ' . number_format($total - $igv, 2), 0, 1, 'C');
    $pdf->Cell(50, 8, 'IGV (18%):', 0, 0, 'R');
    $pdf->Cell(240, 8, 'S/. ' . number_format($igv, 2), 0, 1, 'C');
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(150, 10, 'Total:', 0, 0, 'R');
    $pdf->Cell(40, 10, 'S/. ' . number_format($totalConIgv, 2), 0, 1, 'C');

    // Pie
    $pdf->Ln(8);
    $pdf->SetDrawColor(180, 180, 180);
    $pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
    $pdf->Ln(5);
    $pdf->SetFont('Arial', 'I', 10);
    $pdf->Cell(0, 6, utf8_decode('Gracias por su compra.'), 0, 1, 'C');
    $pdf->Cell(0, 6, utf8_decode('Documento generado electrónicamente por el sistema.'), 0, 1, 'C');

    // Guardar PDF
    $nombreArchivo = 'comprobante_' . $id_comprobante . '_' . date('Ymd_His') . '.pdf';
    $rutaArchivo = '../comprobantes/' . $nombreArchivo;
    $pdf->Output('F', $rutaArchivo);

    echo json_encode([
        "success" => true,
        "message" => "Pago registrado correctamente. Comprobante N° {$numero_comprobante}",
        "pdf" => $rutaArchivo
    ]);
    exit();
} else {
    echo json_encode(["success" => false, "message" => "Error: Acceso denegado"]);
    exit();
}
?>
