<?php
	if (isset($_POST['deletemenu'])) {
		if (!empty($_POST['menuID'])) {
			$idCategoria = $sqlconnection->real_escape_string($_POST['menuID']);
			$deleteArticulosQuery = "DELETE FROM articulo WHERE id_categoria = '{$idCategoria}'";
			if ($sqlconnection->query($deleteArticulosQuery) === TRUE) {
				$deleteCategoriaQuery = "DELETE FROM categoria_articulo WHERE id_categoria = '{$idCategoria}'";
				if ($sqlconnection->query($deleteCategoriaQuery) === TRUE) {
					header("Location: menu.php"); 
					exit();
				} else {
					echo "Error al eliminar la categoría: " . $sqlconnection->error;
				}
			} else {
				echo "Error al eliminar los artículos: " . $sqlconnection->error;
			}
		} else {
			echo "ID de categoría no proporcionado.";
		}
	}
?>