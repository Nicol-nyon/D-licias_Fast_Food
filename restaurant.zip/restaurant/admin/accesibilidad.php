<!-- accesibilidad.php -->
<!-- Item del menú lateral -->

<li class="nav-item">
    <a class="nav-link" href="#" id="configBtn" data-toggle="modal" data-target="#modalAccesibilidad"> 
        <i class="fas fa-fw fa-cog"></i> 
        <span>Accesibilidad</span>
    </a>
</li>

<div id="configPanel" class="config-panel">
  <button id="closeConfigPanel" class="close-btn" title="Cerrar opciones">X</button>
  <h6>Opciones de Accesibilidad</h6>
  <label for="fontSize">Tamaño de letra:</label>
  <select id="fontSize" class="form-control">
    <option value="16px">Normal</option>
    <option value="18px">Grande</option>
    <option value="20px">Muy grande</option>
  </select>
  <label for="contraste" style="margin-top:10px; display:block;">
    <input type="checkbox" id="contraste"> Alto contraste
  </label>
</div>

<script>
    const configBtn = document.getElementById("configBtn");
    const configPanel = document.getElementById("configPanel");
    const closeConfigPanel = document.getElementById("closeConfigPanel"); 
    // Función para abrir/cerrar con el botón principal
    configBtn.addEventListener("click", (e) => {
        e.preventDefault();
        configPanel.style.display =
            configPanel.style.display === "block" ? "none" : "block";
    });
    // Función para cerrar con el botón 'X'
    closeConfigPanel.addEventListener("click", () => {
        configPanel.style.display = "none";
    });
    // CERRAR AL HACER CLIC FUERA DEL PANEL
    document.addEventListener("click", (e) => {
        if (configPanel.style.display === "block") {
            const isClickInsidePanel = configPanel.contains(e.target);
            const isClickOnToggleButton = configBtn.contains(e.target);

            if (!isClickInsidePanel && !isClickOnToggleButton) {
                configPanel.style.display = "none";
            }
        }
    });
    // Control de Tamaño de Letra
    const fontSize = document.getElementById("fontSize");
    fontSize.addEventListener("change", () => {
        document.body.style.fontSize = fontSize.value;
        localStorage.setItem("fontSize", fontSize.value);
    });
    // Control de Contraste
    const contraste = document.getElementById("contraste");
    contraste.addEventListener("change", () => {
        document.body.classList.toggle("contraste", contraste.checked);
        localStorage.setItem("contraste", contraste.checked);
    });
    // Cargar preferencias guardadas al cargar la página
    window.addEventListener("load", () => {
        const savedFontSize = localStorage.getItem("fontSize");
        const savedContraste = localStorage.getItem("contraste") === "true";
        if (savedFontSize) {
            document.body.style.fontSize = savedFontSize;
            fontSize.value = savedFontSize;
        }
        if (savedContraste) {
            document.body.classList.add("contraste");
            contraste.checked = true;
        }
    });
</script>

<style>
  .config-panel {
    display: none;
    position: fixed;
    top: 100px;
    left: 260px;
    background: #f9f9f9; /* Fondo: Sigue siendo un gris muy claro */
    border: 1px solid #ccc;
    padding: 15px;
    border-radius: 8px;
    width: 220px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    z-index: 1050;
    /* >>> AÑADIDO: Asegura que el texto normal sea oscuro <<< */
    color: #333; 
  }
  /* Asegura que los títulos (h6) y etiquetas (label) también sean oscuras */
  .config-panel h6,
  .config-panel label {
    color: #333; 
  }
 body.contraste {
    background-color: #333333 !important;
    color: #FFFFFF !important;
  }
  /* Aplica los colores de contraste a los contenedores principales del sistema */
  body.contraste .card,
  body.contraste .table,
  body.contraste .modal-content {
    background-color: #222222 !important;
    color: #FFFFFF !important;
  }
  /* >>> AÑADIR ESTO PARA EL FOOTER Y SUS ELEMENTOS <<< */
  body.contraste .main-footer,
  body.contraste footer { /* Usa la clase real de tu footer, por ejemplo: .main-footer */
    background-color: #222222 !important; /* Fondo del footer más oscuro */
    color: #FFFFFF !important; /* Texto del copyright claro */
    border-top: 1px solid #444444 !important; /* Si tiene un borde superior */
  }
  /* Para el botón de "subir" (scroll-to-top button) */
  body.contraste .scroll-to-top { /* Usa la clase real de tu botón si tiene una */
    background-color: #555555 !important;
    color: #DDDDDD !important;
  }

    body.contraste #configPanel {
    background-color: #1a1a1a !important; /* Fondo aún más oscuro para que resalte */
    border-color: #FFFFFF !important;
    color: #FFFFFF !important; /* Texto claro */
  }
  body.contraste #configPanel h6,
  body.contraste #configPanel label {
    /* Texto del título y etiquetas */
    color: #FFFFFF !important; 
  }
  body.contraste #configPanel .form-control,
  body.contraste #configPanel select { 
    /* Caja de selección (select) */
    background-color: #333333 !important;
    color: #FFFFFF !important;
    border-color: #FFFFFF !important;
  }
  body.contraste #configPanel select option {
      /* Opciones desplegables del select */
      background-color: #333333 !important;
      color: #FFFFFF !important;
  }
  body.contraste #contraste {
      /* Checkbox de alto contraste */
      accent-color: #FFFFFF !important;
      border-color: #FFFFFF !important;
  }
    .close-btn {
    position: absolute;
    top: 10px;
    right: 10px;
    background: none;
    border: none;
    color: #999; /* Gris suave para modo normal */
    font-size: 20px;
    cursor: pointer;
    width: 30px;
    height: 30px;
    display: flex; /* Centra la 'X' */
    justify-content: center;
    align-items: center;
    border-radius: 50%; /* Lo hace circular */
    transition: background-color 0.2s, color 0.2s;
    z-index: 1060;
  }
  .close-btn:hover {
    color: #333;
    background-color: #e0e0e0;
  }
  /* Estilo del botón en modo contraste */
  body.contraste #configPanel .close-btn {
    color: #FFFFFF !important; /* Blanco puro */
    background-color: transparent !important;
  }
  body.contraste #configPanel .close-btn:hover {
    color: #CCC !important;
    background-color: #333 !important; /* Fondo sutil al pasar el ratón */
  }
</style>
