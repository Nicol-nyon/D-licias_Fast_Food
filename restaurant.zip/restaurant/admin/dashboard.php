<?php
include("../functions.php");
$salesToday = getSalesGrandTotal("DAY");
$salesWeek = getSalesGrandTotal("WEEK");
$salesMonth = getSalesGrandTotal("MONTH");
$salesAllTime = getSalesGrandTotal("ALLTIME");
$topProduct = getTopSellingProduct();
$totalOrders = getTotalOrders();
$totalPayments = getTotalPayments();
$platosVendidos = obtenerPlatosMasVendidos(10);
$nombres_json = json_encode($platosVendidos['nombres']);
$cantidades_json = json_encode($platosVendidos['cantidades']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
  <title>Dashboard - D'licias Fast Food Admin</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <link href="css/sb-admin.css" rel="stylesheet">
  <!-- Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body id="page-top" tyle="background-color:#f4f4f4; padding: 20px;">
    <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
      <a class="navbar-brand mr-1" href="index.php">D'licias Fast Food</a>
      <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
        <i class="fas fa-bars"></i>
      </button>
    </nav>
<div id="wrapper">
    <ul class="sidebar navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="index.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Panel de Control</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="menu.php">
            <i class="fas fa-fw fa-utensils"></i>
            <span>Menú</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="payments.php">
            <i class="fas fa-coins"></i>
            <span>Caja</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="sales.php">
            <i class="fas fa-money-check-alt"></i>
            <span>Ventas</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="dashboard.php">
            <i class="fas fa-chart-area"></i>
            <span>Estadística</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="staff.php">
            <i class="fas fa-fw fa-user-circle"></i>
            <span>Empleados</span>
          </a>
        </li>
        <?php include("accesibilidad.php"); ?>
        <li class="nav-item">
          <a class="nav-link" href="#" data-toggle="modal" data-target="#logoutModal">
            <i class="fas fa-fw fa-power-off"></i>
            <span>Cerrar Sesión</span>
          </a>
        </li>       
      </ul>
  <div id="content-wrapper">
    <div class="container-fluid">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="index.php">Panel de Control</a>
            </li>
            <li class="breadcrumb-item active">Estadística</li>
          </ol>
          <h1>Dashboard</h1>
          <hr>
          			<p>En está seccióno se mustran los reportes en forma grafica</p>
    <!-- Gráfico de ganancias xd -->
    <div class="card">
      <div class="card-header" style="background-color:#716f53; color:white;">
        <i class="fas fa-chart-bar"></i> Gráfico de Ganancias
      </div>
      <div class="card-body d-flex justify-content-center">
        <div style="max-width: 400px; width: 100%;">
          <canvas id="salesChart"></canvas>
        </div>
      </div>
    </div>
    <!-- Grafico de segundos masa vendidos -->
    <div class="card mt-4">
      <div class="card-header bg-info text-white">
        <i class="fas fa-chart-pie"></i> Platos Más Vendidos
      </div>
      <div class="card-body d-flex justify-content-center">
        <div style="max-width: 400px; width: 100%;">
          <canvas id="topPlatosChart"></canvas>
        </div>
      </div>
    </div>
    <br>
    <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Sistema 2025 | D'licias Fast Food</span>
            </div>
          </div>
        </footer>
</div>
  </div>
</div>
<a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header" style="background-color:#feefc4; color:black;">
            <h5 class="modal-title" id="exampleModalLabel">¿Realmente desea cerrar la sesión?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Seleccione "Cerrar sesión" a continuación si está listo para finalizar su sesión actual.</div>
          <div class="modal-footer">
            <button class="btn btn-warning" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-danger" href="logout.php">Cerrar Sesión</a>
          </div>
        </div>
      </div>
    </div>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/sb-admin.min.js"></script>
    <script type="text/javascript"></script>
  <script>
  // Gráfico de barras - GANANCIAS
  var ctx1 = document.getElementById('salesChart').getContext('2d');
  var salesChart = new Chart(ctx1, {
    type: 'bar',
    data: {
      labels: ['Hoy', 'Esta Semana', 'Este Mes', 'Todo el Tiempo'],
      datasets: [{
        label: 'Ganancias (PEN)',
        data: [
          <?php echo $salesToday; ?>,
          <?php echo $salesWeek; ?>,
          <?php echo $salesMonth; ?>,
          <?php echo $salesAllTime; ?>
        ],
        backgroundColor: [
          '#007bff',
          '#17a2b8',
          '#28a745',
          '#ffbc00'
        ],
        borderColor: [
          '#007bff',
          '#17a2b8',
          '#28a745',
          '#ffbc00'
        ],
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: {
          beginAtZero: true
        }
      }
    }
  });
</script>

<script>
  // Gráfico de pastel - PLATOS MÁS VENDIDOS
  const labels = <?php echo $nombres_json; ?>;
  const data = <?php echo $cantidades_json; ?>;
  function generarColorNoBlanco() {
  let color;
  do {
    color = '#' + Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0');
  } while (color.toLowerCase() === '#ffffff' || color.toLowerCase() === '#fff' || color.match(/^#f{3,6}$/i));
  return color;
}
const backgroundColors = labels.map(() => generarColorNoBlanco());
  const ctx2 = document.getElementById('topPlatosChart').getContext('2d');
  const topPlatosChart = new Chart(ctx2, {
    type: 'pie',
    data: {
      labels: labels,
      datasets: [{
        label: 'Cantidad Vendida',
        data: data,
        backgroundColor: backgroundColors,
        borderColor: '#fff',
        borderWidth: 2
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'right'
        }
      }
    }
  });
</script>
</body>
</html>
