<?php
	include("../functions.php");
	if (!isset($_SESSION['uid']) || !isset($_SESSION['username']) || !isset($_SESSION['user_level'])) {
		header("Location: login.php");
		exit();
	}
	if ($_SESSION['user_level'] != "admin" && $_SESSION['user_level'] != "staff") {
		header("Location: login.php");
		exit();
	}
	if (!isset($_GET['orden'])) {
		echo json_encode(['success' => false, 'message' => 'Código de orden no recibido.']);
		exit;
	}
	$id_orden = intval($_GET['orden']);
	$ordenQuery = "SELECT fecha, estado FROM orden_pedido WHERE id_orden = $id_orden";
	$result = $sqlconnection->query($ordenQuery);
	if ($result && $result->num_rows > 0) {
		$orden = $result->fetch_assoc();
		$detalleQuery = "
			SELECT a.nombre, d.cantidad, d.precio_unitario
			FROM detalle_pedido d
			JOIN articulo a ON d.id_articulo = a.id_articulo
			WHERE d.id_orden = $id_orden
		";
		$detalleResult = $sqlconnection->query($detalleQuery);
		$articulos = [];
		$total = 0;
		if ($detalleResult && $detalleResult->num_rows > 0) {
			while ($row = $detalleResult->fetch_assoc()) {
				$subtotal = $row['cantidad'] * $row['precio_unitario'];
				$total += $subtotal;
				$articulos[] = $row;
			}
		}
		echo json_encode([
			'success' => true,
			'fecha' => $orden['fecha'],
			'estado' => ucfirst($orden['estado']),
			'articulos' => $articulos,
			'monto_total' => number_format($total, 2, '.', '')
		]);
	} else {
		echo json_encode(['success' => false, 'message' => 'Orden no encontrada.']);
	}
?>