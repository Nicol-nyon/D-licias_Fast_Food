<?php
	include("../functions.php");
	if ((!isset($_SESSION['uid']) && !isset($_SESSION['username']) && isset($_SESSION['user_level'])))
		header("Location: login.php");
	if ($_SESSION['user_level'] != "admin")
		header("Location: login.php");
	if (empty($_GET['cmd']) || $_GET['cmd'] != 'display')
		die();
	$estadoFiltro = isset($_GET['estado']) ? $_GET['estado'] : "";
	$whereEstado = "";
	if (!empty($estadoFiltro)) {
		$estadoFiltro = $sqlconnection->real_escape_string($estadoFiltro);
		$whereEstado = " AND o.estado = '$estadoFiltro' ";
	}
	$displayOrderQuery =  "
		SELECT o.id_orden, c.nombre_categoria, a.nombre AS nombre_articulo, d.cantidad, o.estado
		FROM orden_pedido o
		JOIN detalle_pedido d ON o.id_orden = d.id_orden
		JOIN articulo a ON d.id_articulo = a.id_articulo
		JOIN categoria_articulo c ON a.id_categoria = c.id_categoria
		WHERE o.estado IN ('Espera', 'Preparando', 'Listo', 'Entregado', 'Cancelado')
		$whereEstado
		ORDER BY o.id_orden ASC
	";
	if ($orderResult = $sqlconnection->query($displayOrderQuery)) {
		$currentspan = 0;
		if ($orderResult->num_rows == 0) {
			echo "<tr><td class='text-center' colspan='6'>No hay órdenes solicitadas por el momento :)</td></tr>";
		} else {
			while ($orderRow = $orderResult->fetch_array(MYSQLI_ASSOC)) {
				$rowspan = getCountID($orderRow["id_orden"], "id_orden", "detalle_pedido");
				if ($currentspan == 0)
					$currentspan = $rowspan;
				echo "<tr>";
				if ($currentspan == $rowspan) {
					echo "<td class='text-center' rowspan='{$rowspan}'># {$orderRow['id_orden']}</td>";
				}
				echo "
					<td>{$orderRow['nombre_categoria']}</td>
					<td>{$orderRow['nombre_articulo']}</td>
					<td class='text-center'>{$orderRow['cantidad']}</td>
				";
				if ($currentspan == $rowspan) {
					$estado = strtolower($orderRow['estado']);
					$colorStyle = "";
					switch ($estado) {
						case 'espera':
							$colorStyle = "background-color: #FFA500; color: white;";
							break;
						case 'cancelado':
							$colorStyle = "background-color: #DC3545; color: white;";
							break;
						case 'listo':
							$colorStyle = "background-color: #32CD32; color: white;";
							break;
						case 'entregado':
							$colorStyle = "background-color: #28A745; color: white;";
							break;
						case 'preparando':
							$colorStyle = "background-color: #FFFF00; color: black;";
							break;
						default:
							$colorStyle = "background-color: gray; color: white;";
							break;
					}
					echo "<td class='text-center' rowspan='{$rowspan}'><span class='badge' style='{$colorStyle}'>{$estado}</span></td>";
				}
				echo "</tr>";
				$currentspan--;
			}
		}
	}
?>
