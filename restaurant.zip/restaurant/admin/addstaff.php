<?php 
	include("../functions.php");
	if (
		(!isset($_SESSION['uid']) || !isset($_SESSION['username']) || !isset($_SESSION['user_level'])) 
	) {
		header("Location: login.php");
		exit();
	}
	if ($_SESSION['user_level'] != "admin") {
		header("Location: login.php");
		exit();
	}
	if (isset($_POST['addstaff'])) {
		if (!empty($_POST['staffname']) && !empty($_POST['stafflastname']) && !empty($_POST['staffrole'])) {
			$nombre = $sqlconnection->real_escape_string($_POST['staffname']);
			$apellido = $sqlconnection->real_escape_string($_POST['stafflastname']);
			$cargo = ucfirst(strtolower($sqlconnection->real_escape_string($_POST['staffrole'])));
			$password = "1234";
			$status = "Offline";
			$prefijo = ($cargo === "admin") ? 'A' : 'E';
			$query = "
				SELECT id_empleado 
				FROM empleado 
				WHERE id_empleado LIKE '{$prefijo}%' 
				ORDER BY id_empleado DESC 
				LIMIT 1
			";
			$result = $sqlconnection->query($query);
			if ($result && $row = $result->fetch_assoc()) {
				$lastID = $row['id_empleado']; 
				$num = (int) substr($lastID, 1);
				$nextNum = $num + 1;
			} else {
				$nextNum = 1;
			}
			$id_empleado = $prefijo . str_pad($nextNum, 4, '0', STR_PAD_LEFT);
			$addQuery = "
				INSERT INTO empleado (id_empleado, nombre, apellido, password, status, cargo)
				VALUES ('$id_empleado', '$nombre', '$apellido', '$password', '$status', '$cargo')
			";
			if ($sqlconnection->query($addQuery) === TRUE) {
				header("Location: staff.php"); 
				exit();
			} else {
				echo "Error al agregar empleado: " . $sqlconnection->error;
				exit();
			}
		} else {
			echo "Todos los campos son obligatorios.";
		}
	}
?>
