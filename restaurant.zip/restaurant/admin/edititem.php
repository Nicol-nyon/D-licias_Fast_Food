<?php
include("../functions.php");
if (!isset($_SESSION['uid']) || !isset($_SESSION['username']) || !isset($_SESSION['user_level'])) {
    header("Location: login.php");
    exit();
}
if ($_SESSION['user_level'] != "admin") {
    header("Location: login.php");
    exit();
}
if (isset($_POST['btnedit'])) {
    if (!empty($_POST['itemName']) && !empty($_POST['itemPrice']) && isset($_POST['itemDispon'])) {
        $id_categoria = $sqlconnection->real_escape_string($_POST['menuID']);
        $id_articulo = $sqlconnection->real_escape_string($_POST['itemID']);
        $nombre = $sqlconnection->real_escape_string($_POST['itemName']);
        $precio = $sqlconnection->real_escape_string($_POST['itemPrice']); 
        $disponibilidad = ($_POST['itemDispon'] == "1") ? 1 : 0;
        $updateQuery = "
            UPDATE articulo 
            SET nombre = '{$nombre}', precio = {$precio}, disponibilidad = {$disponibilidad}
            WHERE id_categoria = '{$id_categoria}' AND id_articulo = '{$id_articulo}'
        ";
        if ($sqlconnection->query($updateQuery) === TRUE) {
            header("Location: menu.php");
            exit();
        } else {
            echo "Error al actualizar el artículo: " . $sqlconnection->error;
        }
    }
}
?>