<?php
  include("../functions.php");
  if((!isset($_SESSION['uid']) && !isset($_SESSION['username']) && isset($_SESSION['user_level'])) ) 
    header("Location: login.php");
  if($_SESSION['user_level'] != "admin")
    header("Location: login.php");
?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Ventas - D'licias Fast Food Admin</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <link href="css/sb-admin.css" rel="stylesheet">
  </head>

  <body id="page-top">
    <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
      <a class="navbar-brand mr-1" href="index.php">D'licias Fast Food</a>
      <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
        <i class="fas fa-bars"></i>
      </button>
    </nav>

    <div id="wrapper">
      <ul class="sidebar navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="index.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Panel de Control</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="menu.php">
            <i class="fas fa-fw fa-utensils"></i>
            <span>Menú</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="payments.php">
            <i class="fas fa-coins"></i>
            <span>Caja</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="sales.php">
            <i class="fas fa-money-check-alt"></i>
            <span>Ventas</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="dashboard.php">
            <i class="fas fa-chart-area"></i>
            <span>Estadística</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="staff.php">
            <i class="fas fa-fw fa-user-circle"></i>
            <span>Empleados</span>
          </a>
        </li>
        <?php include("accesibilidad.php"); ?>
        <li class="nav-item">
          <a class="nav-link" href="#" data-toggle="modal" data-target="#logoutModal">
            <i class="fas fa-fw fa-power-off"></i>
            <span>Cerrar Sesión</span>
          </a>
        </li>
        
      </ul>
      <div id="content-wrapper">
        <div class="container-fluid">
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="index.php">Panel de Control</a>
            </li>
            <li class="breadcrumb-item active">Ventas</li>
          </ol>
          <!-- Page Content -->
          <h1>Administración de Ventas</h1>
          <hr>
          <p>Todos los datos de venta se encuentran aquí.</p>
          <div class="card mb-3">
            <div class="card-header" style="background-color:#03304c; color:white;">
              <i class="fas fa-chart-area"></i>
              Estadística de Ganancias de Ventas
            </div>
            <div class="card-body">
              <table class="table table-bordered" width="100%" cellspacing="0">
                <tbody>
                  <tr>
                    <td>Hoy</td>
                    <td>PEN <?php echo getSalesGrandTotal("DAY"); ?></td>
                  </tr>
                  <tr>
                    <td>Esta Semana</td>
                    <td>PEN <?php echo getSalesGrandTotal("WEEK"); ?></td>
                  </tr>
                  <tr>
                    <td>Este Mes</td>
                    <td>PEN <?php echo getSalesGrandTotal("MONTH"); ?></td>
                  </tr>
                  <tr style="background-color:#6986bd;">
                    <td><b>Todo el Tiempo</b></td>
                    <td><b>PEN <?php echo getSalesGrandTotal("ALLTIME"); ?></b></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <div class="card mb-3">
            <div class="card-header d-flex justify-content-between align-items-center" style="background-color:#03304c; color:white;">
              <div>
                <i class="fas fa-receipt"></i>
                Lista de Órdenes de Ventas
              </div>
              <form method="POST" class="form-inline">
                <div class="d-flex gap-2 flex-wrap align-items-center">
                  <label for="orden" class="mb-1 ml-2"># Orden: </label>
                  <input type="number" name="orden" id="orden" class="form-control form-control-sm ml-2" placeholder="Ej: 101" value="<?= $_POST['orden'] ?? '' ?>">
                  <label for="desde" class="mb-1 ml-5">Desde: </label>
                  <input type="date" name="desde" id="desde" class="form-control form-control-sm ml-2" value="<?= $_POST['desde'] ?? '' ?>">
                  <label for="hasta" class="mb-1 ml-3">Hasta: </label>
                  <input type="date" name="hasta" id="hasta" class="form-control form-control-sm ml-2" value="<?= $_POST['hasta'] ?? '' ?>">
                  <button type="submit" class="btn btn-sm btn-info ml-3">Buscar</button>
                </div>
              </form>
            </div>

            <?php
              $whereCondiciones = [];
              $tituloGanancia = "";
              $hoy = date("Y-m-d");
              // Buscar por número de orden
              if (!empty($_POST['orden'])) {
                $orden = (int) $_POST['orden'];
                $whereCondiciones[] = "o.id_orden = $orden";
                $tituloGanancia = "Ganancia por la Orden #$orden";
              } elseif (!empty($_POST['desde']) && !empty($_POST['hasta'])) {
                // Buscar por fecha
                $desde = $sqlconnection->real_escape_string($_POST['desde']);
                $hasta = $sqlconnection->real_escape_string($_POST['hasta']);
                $whereCondiciones[] = "DATE(cp.fecha_emision) BETWEEN '$desde' AND '$hasta'";
                $tituloGanancia = "Ganancia del $desde al $hasta";
              } else {
                $whereCondiciones[] = "DATE(cp.fecha_emision) = '$hoy'";
                $tituloGanancia = "Ganancia de Hoy ($hoy)";
              }
              $whereSQL = "WHERE " . implode(" AND ", $whereCondiciones);
              $consulta_ganancias = "
                SELECT SUM(d.cantidad * d.precio_unitario) AS total_ganado
                FROM comprobante_pago cp
                JOIN orden_pedido o ON cp.id_orden = o.id_orden
                JOIN detalle_pedido d ON o.id_orden = d.id_orden
                $whereSQL
              ";
              $totalGanado = 0;
              if ($resultado = $sqlconnection->query($consulta_ganancias)) {
                $fila = $resultado->fetch_assoc();
                $totalGanado = $fila['total_ganado'] ?? 0;
              }
            ?>
            <div class="alert alert-success text-center mb-4">
              <strong><?= $tituloGanancia ?>:</strong>
              PEN <?= number_format($totalGanado, 2) ?>
            </div>

            <div class="card-body">
              <table class="table table-bordered" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th class='text-center table-dark'># Orden</th>
                    <th class='text-center table-dark'>Categoría</th>
                    <th class='text-center table-dark'>Producto</th>
                    <th class='text-center table-dark'>Cantidad</th>
                    <th class='text-center table-dark'>Precio Unitario</th>
                    <th class='text-center table-dark'>Fecha de Venta</th>
                    <th class='text-center table-dark'>Total Orden</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                    $query = "
                      SELECT 
                        o.id_orden,
                        c.nombre_categoria,
                        a.nombre AS nombre_articulo,
                        d.cantidad,
                        d.precio_unitario,
                        cp.fecha_emision,
                        cp.id_comprobante
                      FROM comprobante_pago cp
                      JOIN orden_pedido o ON cp.id_orden = o.id_orden
                      JOIN detalle_pedido d ON o.id_orden = d.id_orden
                      JOIN articulo a ON d.id_articulo = a.id_articulo
                      JOIN categoria_articulo c ON a.id_categoria = c.id_categoria
                      $whereSQL
                      ORDER BY cp.fecha_emision DESC, o.id_orden
                    ";

                    $ordenes = [];
                    if ($result = $sqlconnection->query($query)) {
                      while ($row = $result->fetch_assoc()) {
                        $ordenes[$row['id_orden']]['productos'][] = $row;
                        $ordenes[$row['id_orden']]['fecha'] = $row['fecha_emision'];
                        if (!isset($ordenes[$row['id_orden']]['total'])) {
                          $ordenes[$row['id_orden']]['total'] = 0;
                        }
                        $ordenes[$row['id_orden']]['total'] += $row['cantidad'] * $row['precio_unitario'];
                      }

                      if (empty($ordenes)) {
                        echo "<tr><td colspan='7' class='text-center'>No hay ventas registradas para los criterios seleccionados.</td></tr>";
                      } else {
                        foreach ($ordenes as $id_orden => $data) {
                          $rowspan = count($data['productos']);
                          $firstRow = true;
                          foreach ($data['productos'] as $producto) {
                            echo "<tr>";
                            if ($firstRow) {
                              echo "<td rowspan='{$rowspan}' class='text-center align-middle'>#{$id_orden}</td>";
                            }
                            echo "
                              <td>{$producto['nombre_categoria']}</td>
                              <td>{$producto['nombre_articulo']}</td>
                              <td class='text-center'>{$producto['cantidad']}</td>
                              <td class='text-center'>PEN " . number_format($producto['precio_unitario'], 2) . "</td>
                            ";
                            if ($firstRow) {
                              echo "<td rowspan='{$rowspan}' class='text-center align-middle'>{$data['fecha']}</td>";
                              echo "<td rowspan='{$rowspan}' class='text-center align-middle'><b>PEN " . number_format($data['total'], 2) . "</b></td>";
                              $firstRow = false;
                            }
                            echo "</tr>";
                          }
                        }
                      }
                    }
                  ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Sistema 2025 | D'licias Fast Food</span>
            </div>
          </div>
        </footer>
      </div>
    </div>
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header" style="background-color:#feefc4; color:black;">
            <h5 class="modal-title" id="exampleModalLabel">¿Realmente desea cerrar la sesión?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Seleccione "Cerrar Sesión" a continuación si está listo para finalizar su sesión actual.</div>
          <div class="modal-footer">
            <button class="btn btn-warning" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-danger" href="logout.php">Cerrar Sesión</a>
          </div>
        </div>
      </div>
    </div>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/sb-admin.min.js"></script>
  </body>
</html>