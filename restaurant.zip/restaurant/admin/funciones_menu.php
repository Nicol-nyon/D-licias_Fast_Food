<?php
// Obtiene el nombre del archivo actual (ej: "index.php" o "staff.php")
function get_current_page() {
    $url = $_SERVER['REQUEST_URI'];
    $path = basename($url);
    if (empty($path) || $path === 'admin') { // Ajuste para la carpeta raíz si es necesario
        return 'index.php'; 
    }
    return $path;
}

// Función para imprimir 'active' si el enlace coincide con la página actual
function is_active($link_file_name) {
    if (get_current_page() === $link_file_name) {
        echo 'active';
    }
}
?>