<?php
include("../functions.php");
if (
  !isset($_SESSION['uid']) || 
  !isset($_SESSION['username']) || 
  !isset($_SESSION['user_level']) || 
  $_SESSION['user_level'] != "admin"
) {
  header("Location: login.php");
  exit();
}
if (!empty($_POST['cargo']) && !empty($_POST['id_empleado'])) {
  $cargo = $sqlconnection->real_escape_string($_POST['cargo']);
  $id_empleado = $sqlconnection->real_escape_string($_POST['id_empleado']);
  
  $updateRoleQuery = "UPDATE empleado SET cargo = '$cargo' WHERE id_empleado = '$id_empleado'";
  
  if ($sqlconnection->query($updateRoleQuery) !== TRUE) {
    echo "Error al actualizar el cargo: " . $sqlconnection->error;
  } else {
    // redirige para evitar reenvio de formulario al refrescar
    header("Location: staff.php?updated=1");
    exit();
  }
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Administración - D'licias Fast Food Admin</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <link href="css/sb-admin.css" rel="stylesheet">
  </head>
  <body id="page-top">
    <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
      <a class="navbar-brand mr-1" href="index.php">D'licias Fast Food</a>
      <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
        <i class="fas fa-bars"></i>
      </button>
    </nav>
    <div id="wrapper">
       <ul class="sidebar navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="index.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Panel de Control</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="menu.php">
            <i class="fas fa-fw fa-utensils"></i>
            <span>Menú</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="payments.php">
            <i class="fas fa-coins"></i>
            <span>Caja</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="sales.php">
            <i class="fas fa-money-check-alt"></i>
            <span>Ventas</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="dashboard.php">
            <i class="fas fa-chart-area"></i>
            <span>Estadística</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="staff.php">
            <i class="fas fa-fw fa-user-circle"></i>
            <span>Empleados</span>
          </a>
        </li>
        <?php include("accesibilidad.php"); ?>
        <li class="nav-item">
          <a class="nav-link" href="#" data-toggle="modal" data-target="#logoutModal">
            <i class="fas fa-fw fa-power-off"></i>
            <span>Cerrar Sesión</span>
          </a>
        </li>
      </ul>
      <div id="content-wrapper">
        <div class="container-fluid">
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="index.html">Panel de Control</a>
            </li>
            <li class="breadcrumb-item active">Empleados</li>
          </ol>
          <!-- Page Content -->
          <h1>Administración de Empleados</h1>
          <hr>
          <p>Agregar un nuevo empleado, editar cargo o eliminar.</p>
          <div class="row">
            <div class="col-lg-8">
              <div class="card mb-3">
                <div class="card-header" style="background-color:#716f53; color:white;">
                  <i class="fas fa-user-circle"></i>
                  Lista Actual de Empleados</div>
                <div class="card-body">
                  <table class="table table-bordered text-center" id="dataTable" width="100%" cellspacing="0">
                    <tr>
                      <th class='text-center table-dark'>#</th>
                      <th class='text-center table-dark'>Nombre</th>
                      <th class='text-center table-dark'>Apellido</th>
                      <th class='text-center table-dark'>Estado</th>
                      <th class='text-center table-dark'>Cargo</th>
                      <th class='text-center table-dark'>Opción</th>
                    </tr>     
                      <?php 
                        $displayStaffQuery = "SELECT * FROM empleado";
                        if ($result = $sqlconnection->query($displayStaffQuery)) {
                          if ($result->num_rows == 0) {
                            echo "<td colspan='4'>There are currently no staff.</td>";
                          }
                          $staffno = 1;
                          while($staff = $result->fetch_array(MYSQLI_ASSOC)) {
                          ?>  
                          	<tr class="text-center">
                            	<td><?php echo $staffno++; ?></td>
                            	<td><?php echo $staff['nombre']; ?></td>
                              <td><?php echo $staff['apellido']; ?></td>
                              <?php
                            	if ($staff['status'] == "Online") {
                                echo "<td><span class=\"badge badge-success\">En línea</span></td>";
                              }
                              if ($staff['status'] == "Free time") {
                                echo "<td><span class=\"badge badge-secondary\">Tiempo Libre</span></td>";
                              }
                              if ($staff['status'] == "Offline") {
                                echo "<td><span class=\"badge badge-danger\">Inactivo</span></td>";
                              }
                              ?>
                              <!-- cambiar logueo !-->
                              <td>
                                <form method="POST">
                                  <input type="hidden" name="id_empleado" value="<?php echo $staff['id_empleado']; ?>"/>
                                  <select name="cargo" class="form-control" onchange="this.form.submit()">
                                    <?php
                                      $roles = ['Admin', 'Chef', 'Mesero'];

                                      foreach ($roles as $rol) {
                                        $selected = ($rol == $staff['cargo']) ? "selected='selected'" : "";
                                        echo "<option value='$rol' $selected>$rol</option>";
                                      }
                                    ?>
                                  </select>
                                  <noscript><input type="submit" value="Enviar"></noscript>
                                </form>
                              </td>
                            	<td class="text-center">
                                <button 
                                  class="btn btn-sm btn-danger" 
                                  data-toggle="modal" 
                                  data-target="#deleteStaffModal" 
                                  data-id_empleado="<?php echo htmlspecialchars($staff['id_empleado']); ?>">
                                  Eliminar
                              </button>
                              </td>
                        	</tr>
                          <?php 
                          }
                        }
                        else {
                          echo $sqlconnection->error;
                          echo "Something wrong.";
                        }
                      ?>
                  </table>
                </div>
                <div class="card-footer small text-muted"><i>Contraseña predeterminada para nuevo usuario : 1234</i></div>
              </div>
            </div>
            <div class="col-lg-4">
              <div class="card mb-3">
                <div class="card-header" style="background-color:#164731; color:white;">
                  <i class="fas fa-user-plus"></i>
                  Agregar Nuevo Empleado</div>
                <div class="card-body">
                  <form action="addstaff.php" method="POST" class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
                    <div class="input-group">
                      <select name="staffrole" class="form-control">
                        <?php
                          $roles = ['Admin', 'Chef', 'Mesero'];
                          foreach ($roles as $rol) {
                            echo "<option value='$rol'>".ucfirst($rol)."</option>";
                          }
                        ?>
                      </select>
                      <input type="text" required name="staffname" class="form-control" placeholder="Nombre" aria-label="Nombre">
                      <input type="text" required name="stafflastname" class="form-control" placeholder="Apellido" aria-label="Apellido">

                      <div class="input-group-append">
                        <button type="submit" name="addstaff" class="btn btn-info">
                          <i class="fas fa-plus"></i>
                        </button> 
                      </div>
                    </div>
                  </form>
                </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Sistema 2025 | D'licias Fast Food</span>
            </div>
          </div>
        </footer>
      </div>
    </div>
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>
    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header" style="background-color:#feefc4; color:black;">
            <h5 class="modal-title" id="exampleModalLabel">¿Realmente desea cerrar la sesión?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Seleccione "Cerrar sesión" a continuación si está listo para finalizar su sesión actual.</div>
          <div class="modal-footer">
            <button class="btn btn-warning" type="button" data-dismiss="modal">Cancelar</button>
            <a class="btn btn-danger" href="logout.php">Cerrar Sesión</a>
          </div>
        </div>
      </div>
    </div>
    <!-- Delete Staff Modal -->
    <div class="modal fade" id="deleteStaffModal" tabindex="-1" role="dialog" aria-labelledby="deleteStaffModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header" style="background-color:#dc3545; color:white;">
            <h5 class="modal-title" id="deleteStaffModalLabel">¿Estás seguro de eliminar este empleado?</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            Seleccione "Eliminar" a continuación si está seguro de borrar este empleado del sistema.
          </div>
          <div class="modal-footer">
            <form id="deletestaffform" method="POST" action="deletestaff.php">
              <input type="hidden" name="id_empleado" id="delete-id-empleado">
            </form>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
            <button type="submit" form="deletestaffform" class="btn btn-danger" name="deletestaff">Eliminar</button>
          </div>
        </div>
      </div>
    </div>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script>
      $('#deleteStaffModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        var idEmpleado = button.data('id_empleado');
        var modal = $(this);
        modal.find('#delete-id-empleado').val(idEmpleado);
      });
    </script>
    <script src="js/sb-admin.min.js"></script>
  </body>
</html>