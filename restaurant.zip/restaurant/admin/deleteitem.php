<?php
    include("../functions.php");
    if (!isset($_SESSION['uid']) || !isset($_SESSION['username']) || !isset($_SESSION['user_level'])) {
        header("Location: login.php");
        exit();
    }
    if ($_SESSION['user_level'] != "admin") {
        header("Location: login.php");
        exit();
    }
    if (isset($_POST['id_categoria']) && isset($_POST['id_articulo'])) {
        $id_categoria = $sqlconnection->real_escape_string($_POST['id_categoria']);
        $id_articulo = $sqlconnection->real_escape_string($_POST['id_articulo']);

        $deleteQuery = "DELETE FROM articulo WHERE id_categoria = '$id_categoria' AND id_articulo = '$id_articulo'";

        if ($sqlconnection->query($deleteQuery) === TRUE) {
            header("Location: menu.php");
            exit();
        } else {
            echo "Error al eliminar el artículo: " . $sqlconnection->error;
        }
    }
?>
