<?php 
    include("../functions.php");
    if((isset($_SESSION['uid']) && isset($_SESSION['username']) && isset($_SESSION['user_level'])) )  {
        if($_SESSION['user_level'] == "admin") {

            //Cambia el estado del empleado a "Offline" al cerrar sesión
            $uid = $_SESSION['uid'];
            $sqlconnection->query("UPDATE empleado SET status = 'Offline' WHERE id_empleado = '$uid'");
            //Cierra la sesión
        	session_destroy();
         	header("Location: login.php");
        }
        else
        	header("Location: login.php");
    }
    else
    	header("Location: login.php");
?>