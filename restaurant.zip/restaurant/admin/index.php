<?php 
  include("../functions.php");
  if((!isset($_SESSION['uid']) && !isset($_SESSION['username']) && isset($_SESSION['user_level'])) ) 
    header("Location: login.php");
  if($_SESSION['user_level'] != "admin")
    header("Location: login.php");
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>D'licias Fast Food Admin</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <link href="css/sb-admin.css" rel="stylesheet">
  </head>
  <body id="page-top">
    <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
      <a class="navbar-brand mr-1" href="index.php">D'licias Fast Food</a>
      <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
        <i class="fas fa-bars"></i>
      </button>
    </nav>
    <div id="wrapper">
      <?php include("funciones_menu.php"); ?>
      <ul class="sidebar navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="index.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Panel de Control</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="menu.php">
            <i class="fas fa-fw fa-utensils"></i>
            <span>Menú</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="payments.php">
            <i class="fas fa-coins"></i>
            <span>Caja</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="sales.php">
            <i class="fas fa-money-check-alt"></i>
            <span>Ventas</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="dashboard.php">
            <i class="fas fa-chart-area"></i>
            <span>Estadística</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="staff.php">
            <i class="fas fa-fw fa-user-circle"></i>
            <span>Empleados</span>
          </a>
        </li>
        <?php include("accesibilidad.php"); ?>
        <li class="nav-item">
          <a class="nav-link" href="#" data-toggle="modal" data-target="#logoutModal">
            <i class="fas fa-fw fa-power-off"></i>
            <span>Cerrar Sesión</span>
          </a>
        </li>
      </ul>
      <div id="content-wrapper">
        <div class="container-fluid">
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="index.php">Panel de Control</a>
            </li>
            <li class="breadcrumb-item active">Vista General</li>
          </ol>
          <h1>Panel de Monitoreo de Pedidos</h1>
          <hr>
          <p>Visualización de los pedidos en tiempo real y vista de la disponibilidad del personal.</p>
          <div class="row">
            <div class="col-lg-8">
              <div class="card mb-3">
                <div class="card-header d-flex justify-content-between align-items-center" style="background-color:#6895a6; color:ghostwhite;">
                  <div>
                    <i class="fas fa-receipt"></i>
                    Lista General de Pedidos Actuales
                  </div>
                  <div style="min-width: 200px;">
                    <select id="estadoFiltro" class="form-control form-control-sm">
                      <option value="">-- Todos --</option>
                      <option value="Espera">Espera</option>
                      <option value="Preparando">Preparando</option>
                      <option value="Listo">Listo</option>
                      <option value="Entregado">Entregado</option>
                      <option value="Cancelado">Cancelado</option>
                    </select>
                  </div>
                </div>
                <div class="card-body">
                  <table id="tblCurrentOrder" table class="table table-bordered" width="100%" cellspacing="0">
                    <thead>
                      <th class='text-center table-dark'>Número de Orden</th>
                      <th class='text-center table-dark'>Menú</th>
                      <th class='text-center table-dark'>Nombre de Ítem</th>
                      <th class='text-center table-dark'>Cantidad</th>
                      <th class='text-center table-dark'>Estado</th>
                    </thead>  
                    <tbody id="tblBodyCurrentOrder">
                    </tbody>
                  </table>
                </div>
                <div class="card-footer small text-muted"><i>Se refresca automáticamente cada 5 segundos</i></div>
              </div>
            </div>
            <div class="col-lg-4">
              <div class="card mb-3">
                <div class="card-header" style="background-color:#a1bcb9; color:black;">
                  <i class="fas fa-user-check"></i>
                  Disponibilidad del Personal</div>
                <div class="card-body">
                  <table table class="table table-bordered text-center" width="100%" cellspacing="0">
                    <tr>
                      <td class='text-center table-dark'><b>Personal</b></td>
                      <td class='text-center table-dark'><b>Estado</b></td>
                    </tr>
                    <?php 
                      $displayStaffQuery = "SELECT nombre,status FROM empleado";
                          if ($result = $sqlconnection->query($displayStaffQuery)) {
                            while($staff = $result->fetch_array(MYSQLI_ASSOC)) {
                              echo "<tr>";
                              echo "<td>{$staff['nombre']}</td>";

                              if ($staff['status'] == "Online") {
                                echo "<td><span class=\"badge badge-success\">Activo</span></td>";
                              }
                              if ($staff['status'] == "Free time") {
                                echo "<td><span class=\"badge badge-primary\">Tiempo libre</span></td>";
                              }
                              if ($staff['status'] == "Offline") {
                                echo "<td><span class=\"badge badge-danger\">Inactivo</span></td>";
                              } 

                              echo "</tr>";
                            }
                          }
                    ?>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Sistema 2025 | D'licias Fast Food</span>
            </div>
          </div>
        </footer>
      </div>
    </div>
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header" style="background-color:#feefc4; color:black;">
            <h5 class="modal-title" id="exampleModalLabel">¿Realmente desea cerrar la sesión?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Seleccione "Cerrar sesión" a continuación si está listo para finalizar su sesión actual.</div>
          <div class="modal-footer">
            <button class="btn btn-warning" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-danger" href="logout.php">Cerrar Sesión</a>
          </div>
        </div>
      </div>
    </div>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/sb-admin.min.js"></script>
    <script type="text/javascript">
    // Guardar estado actual (opcional con localStorage)
    const savedFilter = localStorage.getItem('estadoFiltro');
    if (savedFilter) {
      document.addEventListener("DOMContentLoaded", function () {
        document.getElementById("estadoFiltro").value = savedFilter;
      });
    }
    // Cargar tabla con estado filtrado
    function refreshTableOrder() {
      const estado = document.getElementById("estadoFiltro").value;
      const url = "displayorder.php?cmd=display" + (estado ? "&estado=" + estado : "");
      $("#tblBodyCurrentOrder").load(url);
    }
    // Detectar cambio en combo box
    $(document).ready(function () {
      $("#estadoFiltro").on("change", function () {
        const selected = $(this).val();
        localStorage.setItem('estadoFiltro', selected); // Guardar selección
        refreshTableOrder();
      });
      // Cargar al iniciar
      refreshTableOrder();
      // Auto-refresh cada 5 segundos
      setInterval(function () {
        refreshTableOrder();
      }, 5000);
    });
  </script>
  </body>
</html>