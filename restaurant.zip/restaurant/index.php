<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>D'Licias Fast Food</title>
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;600;800&display=swap" rel="stylesheet">
  <style>
    * {
      box-sizing: border-box;
    }
    body {
      margin: 0;
      padding: 0;
      background: linear-gradient(135deg, #f6d365, #fda085);
      font-family: 'Nunito', sans-serif;
      height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
    }
    header {
      text-align: center;
      color: white;
      margin-bottom: 50px;
    }
    header h1 {
      font-size: 3.2rem;
      margin: 0;
      text-shadow: 2px 2px 5px rgba(0,0,0,0.3);
    }
    .btn-container {
      display: flex;
      gap: 40px;
      flex-wrap: wrap;
      justify-content: center;
    }
    .btn-link {
      background-color: white;
      color: #e74c3c;
      text-decoration: none;
      font-weight: 600;
      font-size: 1.3rem;
      padding: 15px 35px;
      border-radius: 12px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
      transition: all 0.3s ease;
    }
    .btn-link:hover {
      background-color: #e74c3c;
      color: white;
      transform: scale(1.08);
    }
    footer {
      position: absolute;
      bottom: 15px;
      color: #fff;
      font-size: 0.9rem;
    }
  </style>
</head>
<body>
  <header>
    <h1>D'Licias Fast Food</h1>
  </header>
  <div class="btn-container">
    <a class="btn-link" href="staff">👨‍🍳 Empleados</a>
    <a class="btn-link" href="admin">🔐 Administrador</a>
  </div>
  <footer>
    &copy; <?php echo date("Y"); ?> D'Licias Fast Food.
  </footer>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>
</body>
</html>
