<?php
	require("dbconnection.php");
	session_start();
	function getNumRowsQuery($query) {
		global $sqlconnection;
		if ($result = $sqlconnection->query($query)) {
			return $result->num_rows;
		} else {
			echo "Error en la consulta: " . $sqlconnection->error;
		}
		return 0;
	}

	function getFetchAssocQuery($query) {
		global $sqlconnection;
		if ($result = $sqlconnection->query($query)) {
			return $result;
		} else {
			echo "Error en la consulta: " . $sqlconnection->error;
		}
		return false;
	}
	function getLastID($id, $table) {
		global $sqlconnection;
		$query = "SELECT MAX(id_orden) AS id_orden FROM orden_pedido";
		if ($result = $sqlconnection->query($query)) {
			$res = $result->fetch_array();

			return $res[$id] ?? 0;
		} else {
			echo $sqlconnection->error;
			return null;
		}
	}
	function getCountID($idnum, $id, $table) {
		global $sqlconnection;
		if ($idnum === null) return 0;
		$query = "SELECT COUNT({$id}) AS total FROM {$table} WHERE {$id} = {$idnum}";
		if ($result = $sqlconnection->query($query)) {
			$res = $result->fetch_array();
			return $res['total'] ?? 0;
		} else {
			echo $sqlconnection->error;
			return null;
		}
	}

	function getSalesTotal($orderID) {
		global $sqlconnection;

		if ($orderID === null) return 0;
		$query = "
			SELECT SUM(dp.cantidad * dp.precio_unitario) AS total
			FROM detalle_pedido dp
			WHERE dp.id_orden = {$orderID}
		";

		if ($result = $sqlconnection->query($query)) {
			$res = $result->fetch_array();
			return $res['total'] ?? 0;
		}
		echo $sqlconnection->error;
		return 0;
	}

	function getSalesGrandTotal($periodo) {
		global $sqlconnection;
		$filtroFecha = "";
		switch ($periodo) {
			case "DAY":
				$filtroFecha = "WHERE DATE(cp.fecha_emision) = CURDATE()";
				break;
			case "WEEK":
				$filtroFecha = "WHERE YEARWEEK(DATE(cp.fecha_emision), 1) = YEARWEEK(CURDATE(), 1)";
				break;
			case "MONTH":
				$filtroFecha = "WHERE YEAR(cp.fecha_emision) = YEAR(CURDATE()) AND MONTH(cp.fecha_emision) = MONTH(CURDATE())";
				break;
			case "ALLTIME":
			default:
				$filtroFecha = "";
				break;
		}
		$query = "
			SELECT SUM(d.cantidad * d.precio_unitario) AS total
			FROM comprobante_pago cp
			INNER JOIN orden_pedido o ON cp.id_orden = o.id_orden
			INNER JOIN detalle_pedido d ON o.id_orden = d.id_orden
			$filtroFecha
		";
		$result = $sqlconnection->query($query);
		if ($result && $row = $result->fetch_assoc()) {
			return number_format((float)($row['total'] ?? 0), 2);
		}
		return "0.00";
	}

	function getTotalOrden($id_orden) {
		global $sqlconnection;

		if ($id_orden === null) return 0;
		$query = "
			SELECT SUM(dp.cantidad * a.precio) AS total
			FROM detalle_pedido dp
			JOIN articulo a ON dp.id_articulo = a.id_articulo
			WHERE dp.id_orden = {$id_orden}
		";
		if ($result = $sqlconnection->query($query)) {
			$res = $result->fetch_array();
			return $res['total'] ?? 0;
		}
		return 0;
	}
	function getTopSellingProduct() {
		global $sqlconnection;
		$query = "
			SELECT a.nombre, SUM(dp.cantidad) AS total
			FROM detalle_pedido dp
			JOIN articulo a ON dp.id_articulo = a.id_articulo
			GROUP BY a.nombre
			ORDER BY total DESC
			LIMIT 1
		";
		$result = $sqlconnection->query($query);
		return $result ? $result->fetch_assoc() : null;
		}
			function getTotalOrders() {
			global $sqlconnection;
			$query = "SELECT COUNT(*) AS total FROM orden_pedido WHERE estado = 'entregado'";
			$result = $sqlconnection->query($query);
			return $result ? $result->fetch_assoc()['total'] : 0;
		}
		function getTotalPayments() {
			global $sqlconnection;
			$query = "SELECT COUNT(*) AS total FROM comprobante_pago";
			$result = $sqlconnection->query($query);
			return $result ? $result->fetch_assoc()['total'] : 0;
		}
		function getTop5SellingProducts() {
		global $sqlconnection;
		$query = "
			SELECT a.nombre, SUM(dp.cantidad) AS total
			FROM detalle_pedido dp
			JOIN articulo a ON dp.id_articulo = a.id_articulo
			GROUP BY a.nombre
			ORDER BY total DESC
			LIMIT 5
		";
		$result = $sqlconnection->query($query);
		$data = [];
		if ($result) {
			while ($row = $result->fetch_assoc()) {
				$data[] = $row;
			}
		}
		return $data;
	}
	function obtenerPlatosMasVendidos($limite = 10) {
		global $sqlconnection;
		$sql = "SELECT a.nombre AS nombre_plato, SUM(d.cantidad) AS total_vendido
				FROM detalle_pedido d
				INNER JOIN articulo a ON d.id_articulo = a.id_articulo
				INNER JOIN categoria_articulo c ON a.id_categoria = c.id_categoria
				WHERE c.nombre_categoria NOT IN ('Bebidas', 'Desayuno')
				GROUP BY a.nombre
				ORDER BY total_vendido DESC
				LIMIT $limite";

		$result = $sqlconnection->query($sql);
		$datos = ['nombres' => [], 'cantidades' => []];
		while ($row = $result->fetch_assoc()) {
			$datos['nombres'][] = $row['nombre_plato'];
			$datos['cantidades'][] = $row['total_vendido'];
		}
		return $datos;
	}
?>