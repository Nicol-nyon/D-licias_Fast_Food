<?php
	require('libs/fpdf182/fpdf.php');
	include("dbconfig.php");

	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$tipoComprobante = $_POST['tipoComprobante'];
		$codigoOrden = $_POST['codigoOrden'];
		$metodoPago = $_POST['metodoPago'];
		$nombreCliente = $_POST['nombreCliente'];
		$tipoDocumento = $_POST['tipoDocumento'];
		$numeroDocumento = $_POST['numeroDocumento'];
		$detalleDescripcion = $_POST['detalleDescripcion'];
		$monto = $_POST['monto'];

		$query = "SELECT descripcion FROM metodo_pago WHERE id_metodo = $metodoPago LIMIT 1";
		$result = $sqlconnection->query($query);
		$metodoTexto = $result ? $result->fetch_assoc()['descripcion'] : '---';

		$pdf = new FPDF();
		$pdf->AddPage();

		$pdf->SetFont('Arial', 'B', 16);
		$pdf->Cell(0, 10, strtoupper($tipoComprobante), 0, 1, 'C');

		$pdf->SetFont('Arial', '', 12);
		$pdf->Ln(5);
		$pdf->Cell(0, 10, "Orden N°: $codigoOrden", 0, 1);
		$pdf->Cell(0, 10, "Cliente: $nombreCliente", 0, 1);
		$pdf->Cell(0, 10, "Documento: $tipoDocumento - $numeroDocumento", 0, 1);
		$pdf->Cell(0, 10, "Método de Pago: $metodoTexto", 0, 1);
		$pdf->Cell(0, 10, "Monto: S/ $monto", 0, 1);
		$pdf->MultiCell(0, 10, "Detalle: $detalleDescripcion");

		$pdf->Ln(10);
		$pdf->Cell(0, 10, "Fecha: " . date("d/m/Y H:i"), 0, 1);

		$pdf->Output("I", "comprobante_orden_$codigoOrden.pdf");
	}
?>
